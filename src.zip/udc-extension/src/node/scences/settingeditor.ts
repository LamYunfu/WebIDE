import { injectable } from "inversify";

@injectable()
export class TinyLinkSettingEditor {
    isTinyLinkReady(): boolean {
        return false
    }
    editSettings() {

    }

}