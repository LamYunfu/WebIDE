
export const rootDir = "/home/project"
export const hexFileDir = "hexFiles"
