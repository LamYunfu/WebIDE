export = index;
declare const index: any;
