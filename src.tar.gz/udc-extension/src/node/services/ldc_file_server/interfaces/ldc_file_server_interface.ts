export interface LdcFileServerInterface{
    
}