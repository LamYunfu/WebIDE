export const ModelTestAddress = "ws://47.98.249.190:8005/"
// export const ModelTestAddress = "ws://localhost:8005/"