import { WidgetFactory } from "@theia/core/lib/browser";
import { NewWidget } from "./new_widget-widget";
export declare class NewWidgetFactory implements WidgetFactory {
    widget: NewWidget;
    constructor();
    id: string;
    /**
     * Creates a widget and attaches it to the application shell.
     * @param options serializable JSON data.
     */
    createWidget(options?: any): NewWidget;
}
//# sourceMappingURL=new-widget-factory.d.ts.map