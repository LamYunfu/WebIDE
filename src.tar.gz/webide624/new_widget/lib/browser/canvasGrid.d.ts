export declare class grid {
}
//# sourceMappingURL=canvasGrid.d.ts.map