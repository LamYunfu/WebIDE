import { ContainerModule } from "inversify";
import "../../src/browser/style/index.css";
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=new_widget-frontend-module.d.ts.map