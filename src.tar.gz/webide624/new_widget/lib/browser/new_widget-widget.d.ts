import * as React from "react";
import { ReactWidget } from "@theia/core/lib/browser/widgets/react-widget";
import { MessageService } from "@theia/core";
import { Lamp } from "./Lamp";
export declare class NewWidget extends ReactWidget {
    static readonly ID = "new_widget:widget";
    id: string;
    static readonly LABEL = "Display Board";
    ref: React.RefObject<HTMLCanvasElement>;
    iniImg: Blob;
    lp: Lamp;
    protected readonly messageService: MessageService;
    constructor();
    protected init(): Promise<void>;
    onAfterAttach(): Promise<void>;
    drawPicture(): Promise<void>;
    protected render(): React.ReactNode;
    protected displayMessage(): void;
}
//# sourceMappingURL=new_widget-widget.d.ts.map