export declare class Lamp {
    position: number[];
    status: string;
    cv: HTMLCanvasElement;
    color: string;
    ba: Blob[];
    marginX: number;
    marginY: number;
    leftPort: number[];
    rightPort: number[];
    downPort: number[];
    upPort: number[];
    dimData: Blob;
    screenOn: ImageBitmap;
    screenOff: ImageBitmap;
    screenScheduler: any;
    constructor(screenOn: ImageBitmap, screenOff: ImageBitmap);
    set(cor: number[], cv: HTMLCanvasElement): void;
    readonly x: number;
    readonly y: number;
    drawASlot(): void;
    turnOffScreen(): Promise<void>;
    turnOnScreen(): Promise<void>;
    writeOnScreen(something: string): Promise<void>;
    drawSlot(): void;
    calculatePath(x2: number, y2: number, x1: number, y1: number): void;
    save(): Promise<boolean | undefined>;
    restore(): Promise<void>;
    paint(r: number): Promise<void>;
    lighton(): void;
    lightoff(): void;
    drawX(x: number, y: number, width: number, height: number, label: string): void;
    blink(): Promise<void>;
}
//# sourceMappingURL=Lamp.d.ts.map