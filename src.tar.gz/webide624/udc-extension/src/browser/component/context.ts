import React = require("react");

export const MyContext = React.createContext<Object>({
   

})