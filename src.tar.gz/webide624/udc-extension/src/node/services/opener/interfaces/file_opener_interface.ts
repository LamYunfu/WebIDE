export interface FileOpenerInterface {
  openFile(): void;
}
