export const ModelTrainerInterface=Symbol("ModelTrainerInterface")
export interface ModelTrainerInterface{

}