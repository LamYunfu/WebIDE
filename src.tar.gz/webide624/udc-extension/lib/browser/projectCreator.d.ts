import * as React from "react";
export declare namespace ProjectCreator {
    interface pro {
        initPidQueueInfo(infos: string): Promise<string>;
        setPPid(pid: string | undefined): void;
        showDefault: () => void;
        delProject: (ppid: string) => Promise<boolean>;
    }
    interface st {
        buildTag: boolean;
        projectName: string | undefined;
        projectType: string | undefined;
        ppid: string | undefined;
    }
}
declare type ProjectInfo = {
    ppid: string | undefined;
    buildTag: boolean;
    projectName: string | undefined;
    projectType: string | undefined;
};
export declare class ProjectCreator extends React.Component<ProjectCreator.pro, ProjectCreator.st> {
    constructor(p: any);
    componentDidMount(): void;
    componentWillMount(): Promise<void>;
    projectName: string;
    projectType: string;
    tpMapping: {
        [key: string]: string;
    };
    buttonState: boolean;
    matchProjectType(projectType: string): string[] | undefined;
    createProject: () => void;
    resetProject: () => Promise<void>;
    avoidRepeat(): void;
    renderInput(): React.ReactNode;
    renderShow(): React.ReactNode;
    render(): React.ReactNode;
    storageProjectInfo(info: ProjectInfo): void;
    getProjectInfo(): string | null;
}
export {};
//# sourceMappingURL=projectCreator.d.ts.map