import { WidgetFactory, Widget, ApplicationShell } from "@theia/core/lib/browser";
import { DeviceViewWidgetFactory, DeviceViewWidget, DeviceViewSymbolInformationNode } from "./device-view-widget";
import { Emitter } from "@theia/core/lib/common/event";
export declare class DeviceViewService implements WidgetFactory {
    protected factory: DeviceViewWidgetFactory;
    protected shell: ApplicationShell;
    id: string;
    protected readonly onDidChangeDeviceEmitter: Emitter<DeviceViewSymbolInformationNode[]>;
    protected readonly onDidChangeOpenStateEmitter: Emitter<boolean>;
    protected readonly onDidOpenEmitter: Emitter<DeviceViewSymbolInformationNode>;
    protected readonly onDidSelectEmitter: Emitter<DeviceViewSymbolInformationNode>;
    protected widget?: DeviceViewWidget;
    constructor(factory: DeviceViewWidgetFactory, shell: ApplicationShell);
    openExecutePanel(): void;
    createWidget(): Promise<Widget>;
    setLampStatus(status: boolean): void;
    approveClick(): void;
    openTinyMobile(url: string): void;
    enableClick(): void;
    openShell(): void;
    push(devices: {
        [key: string]: number;
    }): void;
    openWorkspace(url: string): void;
    openExplorer(): void;
    submitOnMenu(): void;
    clearDevices(): void;
    close(): void;
    literalAnalysis(): void;
    gotoCode(file: string): void;
}
//# sourceMappingURL=device-view-service.d.ts.map