/// <reference types="@typefox/monaco-editor-core/monaco" />
import { WidgetManager, OpenerService } from "@theia/core/lib/browser";
import { CommandRegistry, InMemoryResources } from "@theia/core";
import { UdcWatcher } from "./../common/udc-watcher";
import { AboutDialog } from "./about-dailog";
import { UdcService } from "../common/udc-service";
import { NewWidgetFactory } from "../../../new_widget/lib/browser/new-widget-factory";
import { DebugAdapterContribution, DebugAdapterSessionFactory, CommunicationProvider, DebugAdapterSession } from "@theia/debug/lib/common/debug-model";
import { DebugConfiguration } from "@theia/debug/lib/common/debug-configuration";
import { CommandContribution, MenuContribution, MenuModelRegistry, MessageService, Command } from "@theia/core/lib/common";
import { LanguageGrammarDefinitionContribution, TextmateRegistry } from "@theia/monaco/lib/browser/textmate";
import { WorkspaceService } from "@theia/workspace/lib/browser/";
import { FileDialogService } from "@theia/filesystem/lib/browser";
import { FileSystem } from "@theia/filesystem/lib/common";
import { QuickOpenService, QuickOpenModel, QuickOpenItem, QuickOpenItemOptions, ApplicationShell, KeybindingRegistry } from "@theia/core/lib/browser";
import { UdcConsoleSession } from "./udc-console-session";
import { DeviceViewService } from "./device-view-service";
import { EditorManager } from "@theia/editor/lib/browser";
import { EditorQuickOpenService } from "@theia/editor/lib/browser/editor-quick-open-service";
import { LampWidget } from "./lamp";
export declare const UdcExtensionCommand: {
    id: string;
    label: string;
};
export declare namespace UdcMenus {
    const UDC: string[];
    const linkedge: string[];
    const UDC_FUNCTION: string[];
    const UDC_ABOUT: string[];
}
export declare namespace UdcCommands {
    const OpenCommand: Command;
    const GotoCommand: Command;
    const Connect: Command;
    const DisConnect: Command;
    const GetDevList: Command;
    const Program: Command;
    const Reset: Command;
    const Judge: Command;
    const ABOUT: Command;
    const openLab: Command;
    const JudgeButton: Command;
    const PostSrcFile: Command;
    const literalAnalysis: Command;
    const QueryStatus: Command;
    const SetJudgeHostandPort: Command;
    const openViewPanel: Command;
    const openFile: Command;
    const SubmitOnMenu: Command;
    const connectLinkedge: Command;
    const releaseLinkedge: Command;
    const compileEdge: Command;
    const startLinkedge: Command;
    const stopLinkedge: Command;
}
export declare class UdcExtensionCommandContribution implements CommandContribution, QuickOpenModel {
    private readonly messageService;
    protected readonly udcService: UdcService;
    private readonly aboutDialog;
    private readonly lp;
    protected readonly workspaceService: WorkspaceService;
    protected readonly fileDialogService: FileDialogService;
    protected readonly fileSystem: FileSystem;
    protected readonly udcWatcher: UdcWatcher;
    protected readonly quickOpenService: QuickOpenService;
    protected readonly udcConsoleSession: UdcConsoleSession;
    protected readonly deviceViewService: DeviceViewService;
    protected em: EditorManager;
    protected imr: InMemoryResources;
    protected readonly commandRegistry: CommandRegistry;
    protected applicationShell: ApplicationShell;
    protected kr: KeybindingRegistry;
    protected ds: DeviceViewService;
    protected wm: WidgetManager;
    readonly eqos: EditorQuickOpenService;
    readonly os: OpenerService;
    readonly nf: NewWidgetFactory;
    selectDeviceModel: string;
    x: Window | null;
    url: string;
    onType(lookFor: string, acceptor: (items: QuickOpenItem<QuickOpenItemOptions>[]) => void): Promise<void>;
    constructor(messageService: MessageService, udcService: UdcService, aboutDialog: AboutDialog, lp: LampWidget, workspaceService: WorkspaceService, fileDialogService: FileDialogService, fileSystem: FileSystem, udcWatcher: UdcWatcher, quickOpenService: QuickOpenService, udcConsoleSession: UdcConsoleSession, deviceViewService: DeviceViewService, em: EditorManager, imr: InMemoryResources, commandRegistry: CommandRegistry, applicationShell: ApplicationShell, kr: KeybindingRegistry, ds: DeviceViewService, wm: WidgetManager, eqos: EditorQuickOpenService, os: OpenerService, nf: NewWidgetFactory);
    registerCommands(registry: CommandRegistry): void;
}
export declare class debugAdapterSessionFactory implements DebugAdapterSessionFactory {
    get(sessionId: string, communicationProvider: CommunicationProvider): DebugAdapterSession;
}
export declare class DAC implements DebugAdapterContribution {
    type: string;
    label: string;
    languages: string[];
    debugAdapterSessionFactory: {
        get(sessionId: string, communicationProvider: CommunicationProvider): DebugAdapterSession;
    };
    provideDebugAdapterExecutable: (config: DebugConfiguration) => undefined;
}
export declare class UdcExtensionMenuContribution implements MenuContribution {
    registerMenus(menus: MenuModelRegistry): void;
}
export declare class UdcExtensionHighlightContribution implements LanguageGrammarDefinitionContribution {
    readonly id = "cpp";
    readonly scopeName = "source.cpp";
    readonly config: monaco.languages.LanguageConfiguration;
    readonly pyId = "python";
    readonly pyConfig: monaco.languages.LanguageConfiguration;
    registerTextmateLanguage(registry: TextmateRegistry): void;
}
//# sourceMappingURL=udc-extension-contribution.d.ts.map