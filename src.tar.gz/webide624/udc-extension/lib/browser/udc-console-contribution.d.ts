import { AbstractViewContribution } from '@theia/core/lib/browser';
import { interfaces } from "inversify";
import { ConsoleWidget, ConsoleOptions } from '@theia/console/lib/browser/console-widget';
import { ContextKey } from '@theia/core/lib/browser/context-key-service';
export declare type InUdcReplContextKey = ContextKey<boolean>;
export declare const InUdcReplContextKey: unique symbol;
export declare class UdcConsoleWidget extends ConsoleWidget {
    constructor();
    upupup(): void;
}
export declare class UdcConsoleContribution extends AbstractViewContribution<UdcConsoleWidget> {
    constructor();
    static options: ConsoleOptions;
    static create(parent: interfaces.Container): ConsoleWidget;
    static bindContribution(bind: interfaces.Bind): void;
}
//# sourceMappingURL=udc-console-contribution.d.ts.map