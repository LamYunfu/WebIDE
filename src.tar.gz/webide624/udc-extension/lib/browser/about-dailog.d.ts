import { DialogProps, AbstractDialog } from "@theia/core/lib/browser/dialogs";
export declare const UdcDialog_CONTENT_CLASS = "udc-aboutDialog";
export declare const UdcDialog_EXTENSIONS_CLASS = "udc-aboutExtensions";
export declare class AboutDialogProps extends DialogProps {
}
export declare class AboutDialog extends AbstractDialog<void> {
    protected readonly props: AboutDialogProps;
    constructor(props: AboutDialogProps);
    protected init(): Promise<void>;
    readonly value: undefined;
}
//# sourceMappingURL=about-dailog.d.ts.map