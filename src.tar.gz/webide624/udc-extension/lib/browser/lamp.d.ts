import { ReactWidget } from "@theia/core/lib/browser";
import React = require("react");
export declare type LampWidgetFactory = () => Lamp;
export declare const LampViewWidgetFactory: unique symbol;
export declare namespace Lamp {
    interface pro {
        imgDisplay: string;
        lampStatus: boolean;
    }
}
export declare class Lamp extends React.Component<Lamp.pro> {
    state: {
        status: boolean;
    };
    constructor(p: any);
    render(): React.ReactNode;
}
export declare class LampWidget extends ReactWidget {
    constructor();
    render(): React.ReactNode;
}
//# sourceMappingURL=lamp.d.ts.map