/// <reference types="react" />
import { ReactWidget } from "@theia/core/lib/browser";
export declare class TestWidget extends ReactWidget {
    id: string;
    constructor();
    protected render(): React.ReactNode;
}
//# sourceMappingURL=test.d.ts.map