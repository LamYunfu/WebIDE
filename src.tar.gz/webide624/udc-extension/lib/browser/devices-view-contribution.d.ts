import { DeviceViewService } from "./device-view-service";
import { WorkspaceService } from "@theia/workspace/lib/browser/";
import { AbstractViewContribution, FrontendApplicationContribution, FrontendApplication, ApplicationShell, WidgetManager } from "@theia/core/lib/browser";
import { DeviceViewWidget } from "./device-view-widget";
import { FrontendApplicationStateService } from "@theia/core/lib/browser/frontend-application-state";
import { CommandRegistry } from "@theia/core";
import { UdcService } from "../common/udc-service";
export declare const DEVICE_WIDGET_FACTORY_ID = "device-view";
export declare class DeviceViewContribution extends AbstractViewContribution<DeviceViewWidget> implements FrontendApplicationContribution {
    protected applicationShell: ApplicationShell;
    protected applicationState: FrontendApplicationStateService;
    protected registry: CommandRegistry;
    protected ws: WorkspaceService;
    protected wm: WidgetManager;
    protected ds: DeviceViewService;
    readonly udc: UdcService;
    constructor(applicationShell: ApplicationShell, applicationState: FrontendApplicationStateService, registry: CommandRegistry, ws: WorkspaceService, wm: WidgetManager, ds: DeviceViewService, udc: UdcService);
    onStart(app: FrontendApplication): Promise<void>;
    initializeLayout(app: FrontendApplication): Promise<void>;
}
//# sourceMappingURL=devices-view-contribution.d.ts.map