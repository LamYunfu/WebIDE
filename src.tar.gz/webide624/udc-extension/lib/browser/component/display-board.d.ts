import React = require("react");
declare namespace DisplayBoard {
    interface pro {
        setSize: (size: number) => void;
        processDisplaySubmit: (pid: string, info: string) => Promise<void>;
        attach: () => void;
        openWorkSpace: (url: string) => void;
    }
}
export declare class DisplayBoard extends React.Component<DisplayBoard.pro> {
    constructor(props: any);
    componentDidMount(): void;
    state: {
        index: number;
        project: string;
        info: {
            title: string;
            desciption: string;
            pid: string;
        }[];
    };
    setIndex: (index: number) => void;
    render(): React.ReactNode;
}
export declare namespace Board {
    interface prop {
        processDisplaySubmit: (pid: string, info: string) => Promise<void>;
        state: any;
    }
}
export declare class Board extends React.Component<Board.prop> {
    constructor(prop: any);
    burn: () => Promise<void>;
    render(): React.ReactNode;
}
export declare namespace KeyPanel {
    interface pro {
        setIndex: (index: number) => void;
        index: number;
        arr: any[];
        selectedIndex: number;
    }
}
export declare class KeyPanel extends React.Component<KeyPanel.pro> {
    render(): React.ReactNode;
}
export declare namespace Key {
    interface pro {
        selectIndex: number;
        name: string;
        index: number;
        setIndex: (index: number) => void;
    }
}
export declare class Key extends React.Component<Key.pro> {
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=display-board.d.ts.map