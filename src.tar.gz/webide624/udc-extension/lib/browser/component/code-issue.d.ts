import React = require("react");
export declare namespace CodeItem {
    interface Props {
        sid: string;
        akey: string;
        loginType: string;
        model: string;
        role: string[];
        codingStatus: {
            [key: string]: string;
        };
        codingTitles: {
            [key: string]: string;
        };
    }
}
export declare class CodeItem extends React.Component<CodeItem.Props> {
    render(): JSX.Element;
}
export declare namespace CodingInfo {
    interface Props {
        sid: string;
        roles: {
            [key: string]: string[];
        };
        currentFocusCodingIndex: string[];
        issueStatusStrs: {
            [key: string]: string;
        };
        coding_titles: {
            [key: string]: string;
        };
        postSrcFile: (fn: string) => void;
        addCodingSubmittedIssue: (index: string) => void;
        say: (verbose: string) => void;
        config: () => void;
        codeInfoType: string;
        codingInfos: {
            [key: string]: string;
        };
        openShell: () => void;
        programSingleFile: (pidAndFn: string) => void;
        viewType?: string;
    }
    interface States {
        pid: string;
        singleFileButtons: JSX.Element[];
        currentFile: string;
        connectionStatus: string;
    }
}
export declare class CodingInfo extends React.Component<CodingInfo.Props, CodingInfo.States> {
    focusFile: string;
    constructor(props: Readonly<CodingInfo.Props>);
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=code-issue.d.ts.map