import React = require("react");
export declare namespace OneLinkView {
    interface Props {
        initPid: (pid: string) => void;
        gotoVirtualScene: () => void;
        gotoPhone: () => void;
        gotoUnity: () => void;
        openUnity: () => void;
        openFileView: () => void;
        complileMobile: () => Promise<boolean>;
        compileDevice: () => Promise<boolean>;
        openMobile: () => void;
        openDevice: () => void;
        createOnelinkProject: (projectName: string, pid: string) => Promise<boolean>;
        section: {
            [key: string]: any;
        };
        title: string;
        config: () => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        initPidQueueInfo(infos: string): Promise<string>;
    }
    interface State {
        codingItems: JSX.Element[];
    }
}
export declare class OneLinkView extends React.Component<OneLinkView.Props, OneLinkView.State> {
    pidQueueInfo: {
        [pid: string]: {};
    };
    pids: string[];
    codingItems: JSX.Element[];
    projectName: string;
    constructor(props: Readonly<OneLinkView.Props>);
    componentWillMount(): void;
    submit: () => void;
    componentDidMount(): Promise<void>;
    createMobile: () => Promise<void>;
    createProject: () => Promise<void>;
    complileMobile: () => Promise<void>;
    compileDevice: () => Promise<void>;
    openMobile: () => Promise<void>;
    openDevice: () => Promise<void>;
    changeAppName: (e: any) => void;
    render(): JSX.Element;
}
//# sourceMappingURL=onelink-view.d.ts.map