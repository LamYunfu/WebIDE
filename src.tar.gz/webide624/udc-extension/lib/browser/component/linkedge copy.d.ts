import React = require("react");
export declare namespace LinkEdge {
    interface Props {
        initLinkedgeConfig: (pid: string) => Promise<boolean>;
        linkEdgeDisconnect: () => void;
        linkEdgeConnect: (pid: string, threeTuple: any) => Promise<boolean>;
        initPidQueueInfo(infos: string): Promise<string>;
        setSize(size: number): void;
        remove: (pid: string, index: string) => Promise<boolean>;
        develop(pid: string, indexStr: string): Promise<boolean>;
        add(pid: string, info: any): Promise<boolean>;
        getDevicesInfo(pid: string): Promise<any>;
    }
    interface State {
        connectionStatus: boolean;
        executeStatus: boolean;
        connectionLoading: boolean;
        executeLoading: boolean;
        ra: any[];
    }
}
export declare class LinkEdgeView extends React.Component<LinkEdge.Props, LinkEdge.State> {
    pid: string;
    threeTuple: any;
    constructor(props: LinkEdge.Props);
    componentDidMount(): void;
    getPid(): string;
    componentWillMount(): Promise<void>;
    toggleConnectionStatus: () => Promise<void>;
    toggleExecuteStatus: () => Promise<void>;
    changeDeviceName: (e: any) => void;
    changeDeviceSecret: (e: any) => void;
    changeProductKey: (e: any) => void;
    add: (deviceInfo: any) => Promise<boolean>;
    develop: (index: string) => Promise<boolean>;
    getRa: () => Promise<any>;
    setRa: (ra: any) => void;
    remove: (index: string) => Promise<boolean>;
    render(): JSX.Element;
}
export declare namespace Input {
    interface Props {
        onChange?: (e: any) => void;
        disabled?: boolean;
        label: string;
        hint: string;
        copy?: boolean;
    }
}
export declare class Input extends React.Component<Input.Props> {
    index: number;
    str: string;
    onChange: (e: any) => void;
    render(): JSX.Element;
    copy: () => void;
}
//# sourceMappingURL=linkedge copy.d.ts.map