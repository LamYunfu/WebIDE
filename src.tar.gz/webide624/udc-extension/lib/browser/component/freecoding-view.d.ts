import React = require("react");
export declare namespace FreeCoding {
    interface Props {
        title: string;
        section: {
            [key: string]: any;
        };
        connect: (loginType: string, model: string, pid: string, timeout: string) => void;
        disconnect: () => void;
        callUpdate: () => void;
        postSrcFile: (fn: string) => void;
        config: () => void;
        setCookie: (cookie: string) => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        setQueue: () => void;
        closeTabs: () => void;
        initPidQueueInfo(infos: string): Promise<string>;
        openShell: () => void;
        programSingleFile: (pidAndFn: string) => void;
    }
    interface State {
        codingItems: JSX.Element[];
    }
}
export declare class FreeCoding extends React.Component<FreeCoding.Props, FreeCoding.State> {
    timeout: {
        [pid: string]: string;
    };
    model: {
        [key: string]: string;
    };
    ppids: {
        [key: string]: string;
    };
    loginType: {
        [key: string]: string;
    };
    role: {
        [key: string]: string[];
    };
    currentFocusCodingIndex: string[];
    codingIssues: {
        [key: string]: string;
    };
    codingInfos: {
        [key: string]: string;
    };
    codingStatus: {
        [key: string]: string;
    };
    judgeStatus: string[];
    submittedCodingIssue: string[];
    pidQueueInfo: {
        [pid: string]: {};
    };
    statusCode: {
        [key: number]: string;
    };
    statusColors: {
        [key: number]: string;
    };
    pids: string[];
    codingItems: JSX.Element[];
    addSubmittedCodingIssue: (issueIndex: string) => void;
    constructor(props: Readonly<FreeCoding.Props>);
    componentWillMount(): Promise<void>;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=freecoding-view.d.ts.map