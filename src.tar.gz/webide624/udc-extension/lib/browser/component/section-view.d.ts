import React = require("react");
export declare namespace SectionUI {
    interface Props {
        sid: string;
        sectionData: {
            [key: string]: {
                answer: string;
                isRight: boolean;
            };
        };
        setSectionDataPool: (sid: string, data: {}) => void;
        section: {
            [key: string]: string;
        };
        connect: (loginType: string, model: string, pid: string, timeout: string) => void;
        disconnect: () => void;
        callUpdate: () => void;
        postSrcFile: (fn: string) => void;
        config: () => void;
        ppidArr: string[];
        gotoVideo: (uri: string, videoName: string) => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        setQueue: () => void;
        initPidQueueInfo: (infos: string) => Promise<string>;
        closeTables: () => void;
        openShell: () => void;
        seq: number;
        setLocal: (key: string, obj: any) => void;
        getLocal: (key: string, obj: any) => any;
        programSingleFile: (pidAndFn: string) => void;
        vid: string;
        viewType: string;
    }
    interface State {
        codeCDM: boolean;
        codingItems: JSX.Element[];
        optionItems: JSX.Element[];
    }
}
export declare class SectionUI extends React.Component<SectionUI.Props, SectionUI.State> {
    timeout: {
        [key: string]: string;
    };
    model: {
        [key: string]: string;
    };
    loginType: {
        [key: string]: string;
    };
    role: {
        [key: string]: string[];
    };
    ppids: {
        [key: string]: string;
    };
    currentFocusCodingIndex: string[];
    optionIssues: {
        [key: string]: string;
    };
    optionStatus: {
        [key: string]: string;
    };
    choices: {
        [key: string]: string[];
    };
    answers: {
        [key: string]: string;
    };
    codingIssues: {
        [key: string]: string;
    };
    codingInfos: {
        [key: string]: string;
    };
    codingStatus: {
        [key: string]: string;
    };
    judgeStatus: string[];
    submittedOptionIssue: {
        [key: string]: string;
    };
    submittedCodingIssue: string[];
    statusCode: {
        [key: number]: string;
    };
    statusColors: {
        [key: number]: string;
    };
    videoNames: string[];
    uris: string[];
    pids: string[];
    optionItems: JSX.Element[];
    codingItems: JSX.Element[];
    pidQueueInfo: {
        [pid: string]: {};
    };
    types: {
        [pid: string]: string;
    };
    scids: {
        [pid: string]: string;
    };
    lastSubmitCount: {
        [pid: string]: any;
    };
    static contextType: React.Context<Object>;
    readonly submittedOptionAnswers: {
        [key: string]: {
            answer: string;
            isRight: boolean;
        };
    };
    setSubmittedOptionAnswer: (pid: string, answer: string, isRight: boolean) => void;
    addSubmittedCodingIssue: (issueIndex: string) => void;
    constructor(props: Readonly<SectionUI.Props>);
    componentWillMount(): Promise<void>;
    submittedOptionStatus: {
        [key: string]: string;
    };
    componentDidMount(): Promise<void>;
    recoveryState(): Promise<void>;
    upDateCount: number;
    componentDidUpdate(): void;
    render(): React.ReactNode;
}
//# sourceMappingURL=section-view.d.ts.map