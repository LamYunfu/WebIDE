import React = require("react");
export declare namespace Chapter {
    interface Props {
        viewType: string;
        vid: string;
        chapterData: {
            [key: string]: {};
        };
        sectionData: any;
        sections: [{
            [key: string]: string;
        }];
        connect: (loginType: string, model: string, pid: string, timeout: string) => void;
        disconnect: () => void;
        callUpdate: () => void;
        postSrcFile: (fn: string) => void;
        config: () => void;
        gotoVideo: (uri: string, videoName: string) => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        setChapterData: (vid: string, data: {}) => void;
        setQueue: () => void;
        initPidQueueInfo(infos: string): Promise<string>;
        closeTables: () => void;
        openShell: () => void;
        setLocal: (key: string, obj: object) => void;
        getLocal: (key: string, obj: object) => object;
        programSingleFile: (pidAndFn: string) => void;
    }
}
export declare class Chapter extends React.Component<Chapter.Props> {
    sidArray: string[];
    readonly sectionsDataPool: {
        [key: string]: {};
    };
    setSectionsDataPool: (sid: string, sectionData: {}) => void;
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=chapter-view.d.ts.map