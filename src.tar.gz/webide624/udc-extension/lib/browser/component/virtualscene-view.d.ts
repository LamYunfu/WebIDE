import React = require("react");
export declare namespace VirtualScene {
    interface Props {
        section: {
            [key: string]: any;
        };
        title: string;
        config: () => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        initPidQueueInfo(infos: string): Promise<string>;
    }
    interface State {
        codingItems: JSX.Element[];
    }
}
export declare class VirtualSceneView extends React.Component<VirtualScene.Props, VirtualScene.State> {
    pidQueueInfo: {
        [pid: string]: {};
    };
    pids: string[];
    codingItems: JSX.Element[];
    constructor(props: Readonly<VirtualScene.Props>);
    componentWillMount(): void;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=virtualscene-view.d.ts.map