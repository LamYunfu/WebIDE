import React = require("react");
export declare namespace View {
    interface Props {
        storeCallInfo: (time: string, info: string, api: string, serverity: number) => void;
        openLinkEdge: () => void;
        delProject: (pid: string) => Promise<boolean>;
        initPid: (pid: string) => void;
        openConfigFile: (pid: string) => void;
        initLinkedge: (pid: string) => Promise<boolean>;
        gotoPhone: () => void;
        gotoUnity: () => void;
        openUnity: () => void;
        complileMobile: () => Promise<boolean>;
        compileDevice: () => Promise<boolean>;
        openMobile: () => void;
        openDevice: () => void;
        createOnelinkProject: (projectName: string, pid: string) => Promise<boolean>;
        remove: (pid: string, index: string) => Promise<boolean>;
        linkEdgeGetDevicesInfo: (pid: string) => Promise<any>;
        linkEdgeProjectAdd: (pid: string, info: any) => Promise<boolean>;
        linkEdgeDevelop: (pid: string, indexStr: string) => Promise<boolean>;
        linkEdgeConnect: (pid: string, threeTuple: any) => Promise<boolean>;
        openDrawBoard: () => void;
        gotoVirtualScene: () => void;
        virtualOpen: () => void;
        virtualSubmit: (pid: string) => void;
        openExplorer: () => void;
        openFileView: () => void;
        terminateExe: () => void;
        continueExe: () => void;
        getData: (type: string) => Promise<string>;
        storeData: (data: string) => void;
        connect: (loginType: string, model: string, pid: string, timeout: string) => Promise<boolean>;
        isconnected: () => Promise<Boolean>;
        disconnect: () => void;
        callUpdate: () => void;
        postSrcFile: (fn: string) => void;
        setCookie: (cookie: string) => void;
        gotoVideo: (uri: string, videoName: string) => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        setSize: (size: number) => void;
        setQueue: () => void;
        closeTabs: () => void;
        initPidQueueInfo(infos: string): Promise<string>;
        openShell: () => void;
        setTinyLink: (name: string, passwd: string, uid: string) => void;
        config: () => void;
        setLocal: (key: string, obj: object) => void;
        getLocal: (key: string, obj: object) => any;
        programSingleFile: (pidAndFn: string) => void;
        postSimFile: (pid: string) => void;
        openSrcFile: (pid: string) => void;
        saveAll: () => void;
        setSubmitEnableWithJudgeTag: (val: boolean) => void;
        getSubmitEnableWithJudgeTag: () => boolean;
        openWorkSpace: (urlStr: string) => void;
        train: (pid: string) => void;
        processDisplaySubmit: (pid: string, info: string) => Promise<void>;
        attach: () => void;
    }
    interface State {
        ajaxNotFinish: boolean;
        optionDescription: string;
        optionChoicesDecription: JSX.Element[];
        sid: string;
        pid: string;
        viewType: string;
        scid: string;
        sidArray: string[];
        isLast: boolean;
        sidIndex: number;
        qzid: string;
        type: string;
        defaultOptionViewToogle: boolean;
        redo: boolean;
        viewState: boolean;
    }
}
export declare class View extends React.Component<View.Props, View.State> {
    constructor(props: Readonly<View.Props>);
    vid: string;
    type: string;
    title: string;
    ppid: string;
    sections: [{
        [key: string]: string;
    }];
    renderView: JSX.Element;
    typeDataPool: {
        [key: string]: {
            [key: string]: {};
        };
    };
    answerPool: {
        [section: string]: {
            [index: string]: {
                uAnswer: string | undefined;
                isRight: boolean | undefined;
            };
        };
    };
    questionPool: {
        [section: string]: any;
    };
    submittedAnswers: {
        [sid: string]: {
            [index: string]: {
                uAnswer: string[] | undefined;
                uRight: boolean | undefined;
                saved: boolean | undefined;
            };
        };
    };
    notForAll: boolean;
    clickTime: number;
    sectionData: any;
    typeData: any;
    setAnswerPool: (section: string, index: string, data: any) => void;
    setOptionDescription: (ds: string) => void;
    setOptionChoicesDescription: (dss: JSX.Element[]) => void;
    setChapterData: (vid: string, chapterData: {}) => void;
    componentWillMount(): Promise<void>;
    toggleRedoButton(): void;
    showSubmitButton(): void;
    showRedoButton(): void;
    componentDidUpdate(): Promise<void>;
    componentWillUpdate(): void;
    componentDidMount(): void;
    showTheDefaultExperimentView(): Promise<void>;
    showTheDefaultSceneView(): Promise<void>;
    showTheDefaultOptionView(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=renderView.d.ts.map