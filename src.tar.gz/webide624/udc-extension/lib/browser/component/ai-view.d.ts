import React = require("react");
export declare namespace AI {
    interface Props {
        section: {
            [key: string]: any;
        };
        title: string;
        config: () => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        initPidQueueInfo(infos: string): Promise<string>;
    }
    interface State {
        codingItems: JSX.Element[];
    }
}
export declare class AIView extends React.Component<AI.Props, AI.State> {
    pidQueueInfo: {
        [pid: string]: {};
    };
    pids: string[];
    codingItems: JSX.Element[];
    constructor(props: Readonly<AI.Props>);
    componentWillMount(): void;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=ai-view.d.ts.map