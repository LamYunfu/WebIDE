import React = require("react");
export declare namespace Experiment {
    interface Props {
        section: {
            [key: string]: any;
        };
        connect: (loginType: string, model: string, pid: string, timeout: string) => Promise<boolean>;
        disconnect: () => void;
        callUpdate: () => void;
        postSrcFile: (fn: string) => void;
        config: () => void;
        setCookie: (cookie: string) => void;
        say: (verbose: string) => void;
        outputResult: (res: string, types?: string) => void;
        setQueue: () => void;
        closeTabs: () => void;
        initPidQueueInfo(infos: string): Promise<string>;
        openShell: () => void;
        programSingleFile: (pidAndFn: string) => void;
    }
    interface State {
        codingItems: JSX.Element[];
    }
}
export declare class Experiment extends React.Component<Experiment.Props, Experiment.State> {
    timeout: {
        [pid: string]: string;
    };
    model: {
        [key: string]: string;
    };
    boardType: {
        [key: string]: string;
    };
    compileMethod: {
        [key: string]: string;
    };
    deviceType: {
        [key: string]: string;
    };
    ppids: {
        [key: string]: string;
    };
    loginType: {
        [key: string]: string;
    };
    role: {
        [key: string]: string[];
    };
    currentFocusCodingIndex: string[];
    codingIssues: {
        [key: string]: string;
    };
    codingInfos: {
        [key: string]: string;
    };
    codingStatus: {
        [key: string]: string;
    };
    judgeStatus: string[];
    submittedCodingIssue: string[];
    pidQueueInfo: {
        [pid: string]: {};
    };
    statusCode: {
        [key: number]: string;
    };
    statusColors: {
        [key: number]: string;
    };
    pids: string[];
    codingItems: JSX.Element[];
    lastSubmitCount: {
        [pid: string]: any;
    };
    addSubmittedCodingIssue: (issueIndex: string) => void;
    constructor(props: Readonly<Experiment.Props>);
    componentWillMount(): void;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=experiment-view.d.ts.map