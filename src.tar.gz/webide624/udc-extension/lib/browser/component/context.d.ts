import React = require("react");
export declare const MyContext: React.Context<Object>;
//# sourceMappingURL=context.d.ts.map