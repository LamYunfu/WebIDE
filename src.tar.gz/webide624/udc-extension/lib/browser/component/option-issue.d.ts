import React = require("react");
export declare namespace OptionItem {
    interface Props {
        type: string;
        sid: string;
        akey: string;
        titles: {
            [key: string]: string;
        };
        choices: {
            [key: string]: string[];
        };
        optionStatus: {
            [key: string]: string;
        };
        optionIssues: {
            [key: string]: string;
        };
        qzid: string;
        scid: string;
        uRight: boolean | undefined;
        saved: boolean | undefined;
    }
}
export declare class OptionItem extends React.Component<OptionItem.Props> {
    componentWillMount(): void;
    componentDidMount(): void;
    render(): JSX.Element;
}
export declare namespace OptionInfo {
    interface Props {
        contentsCollection: {
            [key: string]: string[];
        };
        answersCollection: {
            [key: string]: string;
        };
        titlesCollection: {
            [key: string]: string;
        };
        sid: string;
        answers: {
            [key: string]: string;
        };
        submittedOptionAnswers: {
            [pid: string]: {
                answer: string;
                isRight: boolean;
            };
        };
        setSubmittedOptionAnswer: (pid: string, answer: string, isRight: boolean) => void;
        say: (thing: string) => void;
        types: {
            [key: string]: string;
        };
        setLocal: (key: string, obj: object) => void;
        getLocal: (key: string, obj: object) => object;
        submitStyle: string;
    }
    interface States {
        status: string;
    }
}
export declare class OptionInfo extends React.Component<OptionInfo.Props, OptionInfo.States> {
    render(): JSX.Element;
}
export declare namespace Choice {
    interface Props {
        sid: string;
        content: string;
        choiceNum: string;
        type: string;
        pid: string;
        checked: boolean;
    }
    interface States {
        checked: boolean;
    }
}
export declare class Choice extends React.Component<Choice.Props, Choice.States> {
    constructor(props: Readonly<Choice.Props>);
    render(): JSX.Element;
    componentDidMount(): void;
    componentWillMount(): void;
    componentWillUpdate(): void;
    componentDidUpdate(): void;
}
export declare namespace ChoiceCollection {
    interface Props {
        contentsCollection: {
            [key: string]: string[];
        };
        titlesCollection: {
            [key: string]: string;
        };
        sid: string;
        types: {
            [key: string]: string;
        };
        setLocal: (key: string, obj: any) => void;
        getLocal: (key: string, obj: any) => any;
        submitStyle: string;
    }
    interface States {
        sid: string;
        uAnswers: {
            [key: string]: any;
        };
        contents: string[];
        pid: string;
        title: string;
        type: string;
        submitStyle: string;
        qzid: string;
        scid: string;
    }
}
export declare class ChoiceCollection extends React.Component<ChoiceCollection.Props, ChoiceCollection.States> {
    uAnswers: {
        [pid: string]: {
            answer: string[];
            uRight: boolean | undefined;
        };
    };
    isSubmitted: boolean;
    constructor(props: Readonly<ChoiceCollection.Props>);
    componentWillMount(): Promise<void>;
    render(): JSX.Element;
    componentDidMount(): Promise<void>;
}
//# sourceMappingURL=option-issue.d.ts.map