import React = require("react");
export declare namespace VideoItem {
    interface Props {
        sid: string;
        title: string;
        videoNames: string[];
        uris: string[];
        gotoVideo: (uri: string, videoName: string) => void;
    }
}
export declare class VideoItem extends React.Component<VideoItem.Props> {
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=video-view.d.ts.map