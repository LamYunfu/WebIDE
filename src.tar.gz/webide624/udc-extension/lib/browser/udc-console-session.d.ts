import { ConsoleSession, ConsoleItem } from "@theia/console/lib/browser/console-session";
import URI from "@theia/core/lib/common/uri";
import { Workspace, Languages } from "@theia/languages/lib/browser";
import { UdcService } from "../common/udc-service";
import { UdcConsoleWidget } from "./udc-console-contribution";
export declare class UdcConsoleSession extends ConsoleSession {
    protected readonly languages: Languages;
    protected readonly workspace: Workspace;
    protected readonly udcService: UdcService;
    static uri: URI;
    readonly id = "udc";
    protected items: ConsoleItem[];
    protected consoleWidget: Promise<UdcConsoleWidget> | undefined;
    constructor(languages: Languages, workspace: Workspace, udcService: UdcService);
    getElements(): IterableIterator<ConsoleItem>;
    execute(cmd: string): Promise<void>;
    appendLine(value: string): Promise<void>;
    clear(): void;
    protected fireDidChange(): void;
    setWidget(widget: Promise<UdcConsoleWidget>): void;
}
//# sourceMappingURL=udc-console-session.d.ts.map