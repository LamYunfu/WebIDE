import { ReactWidget, WidgetFactory } from "@theia/core/lib/browser";
import React from "react";
export declare class DemoFactory implements WidgetFactory {
    id: string;
    createWidget(option?: any): DemoWidget;
}
export declare class DemoWidget extends ReactWidget {
    id: string;
    render(): React.ReactNode;
}
//# sourceMappingURL=demo.d.ts.map