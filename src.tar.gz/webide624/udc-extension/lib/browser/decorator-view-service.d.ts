import { AbstractTreeDecoratorService, TreeDecorator } from "@theia/core/lib/browser";
import { ContributionProvider } from "@theia/core";
export declare const DeviceTreeDecorator: unique symbol;
export declare class DeviceViewDecoratorService extends AbstractTreeDecoratorService {
    protected readonly contributions: ContributionProvider<TreeDecorator>;
    constructor(contributions: ContributionProvider<TreeDecorator>);
}
//# sourceMappingURL=decorator-view-service.d.ts.map