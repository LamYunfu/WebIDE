export declare const DEPLOY_SERVER_DOMAIN = "test.tinylink.cn";
export declare const DEPLOY_SERVER_IP = "120.55.102.225";
export declare const FILE_SERVER_HOST = "fileserver.test.tinylink.cn";
export declare const CONTIKI_IP: string;
export declare const CONTIKI_PORT = "12382";
export declare const ALIOS_IP: string;
export declare const ALIOS_PORT = "12305";
export declare const TINYLINK_HOST: string;
export declare const PROGRAM_SERVER_IP: string;
export declare const PROGRAM_SERVER_PORT = "8081";
export declare const SENCE_SERVER_URL = "ws://47.98.249.190:8004/";
export declare const LDC_SERVER_IP: string;
export declare const LDC_SERVER_PORT = 65003;
export declare const TEMPLATE_SERVER: string;
export declare const RASPBERRY_QUERRY_IP = "120.55.102.225";
export declare const RASPBERRY_QUERRY_PORT = "12320";
export declare const TINY_MOBILE_IP: string;
export declare const TINY_MOBILE_PORT = "12355";
export declare const TINYLINEDGECOMPILE_IP = "47.96.155.111";
export declare const RASPBERRY_GCC_IP = "120.55.102.225";
export declare const RASPBERRY_GCC_PORT = "12400";
export declare const DISTRIBUTEDCOMPILER_IP = "kubernetes.tinylink.cn";
export declare const Call_Log_Path = "/home/project/call_info.log";
export declare const CONFIGPATH = "/home/config";
export declare class RootDirPath {
    private rootDir;
    val: string;
    reset(): void;
}
//# sourceMappingURL=backend-config.d.ts.map