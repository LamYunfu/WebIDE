export declare namespace CallSymbol {
    const CCCE = "\u4E8E\u5206\u5E03\u5F0F\u7F16\u8BD1\u5668\u7F16\u8BD1\u4EE3\u7801";
    const DNHX = "\u4E8E\u5206\u5E03\u5F0F\u7F16\u8BD1\u5668\u4E0B\u8F7Dhex";
    const WTCP = "\u7B49\u5F85\u7F16\u8BD1\u5B8C\u6210";
    const CDAT = "\u4E8EtinyLink\u7F16\u8BD1\u4EE3\u7801";
    const DHFT = "\u4E8Etinylink\u4E0B\u8F7Dhex";
    const GTML = "\u83B7\u53D6\u6A21\u677F";
    const GESI = "\u67E5\u8BE2ssh\u4FE1\u606F";
    const GTSD = "\u67E5\u8BE2\u670D\u52A1\u90E8\u7F72";
    const TECC = "tinyEdge\u7F16\u8BD1";
    const TISM = "tinysim";
    const IPCF = "\u70E7\u5199\u521D\u59CB\u5316";
    const FLUP = "\u70E7\u5199\u6587\u4EF6\u4E0A\u4F20";
    const LDDC = "LDC\u8BBE\u5907\u8FDE\u63A5";
    const LDDP = "LDC\u8BBE\u5907\u70E7\u5199";
    const CTPJ = "\u521B\u5EFAtinymobile\u5DE5\u7A0B";
    const UPTP = "\u66F4\u65B0tinymobile\u5DE5\u7A0B";
    const CTTM = "\u5B9A\u5236tinymobile";
    const QUIF = "\u67E5\u770B\u7528\u6237\u4FE1\u606F";
    const QCVI = "\u67E5\u770B\u5F53\u524D\u89C6\u56FE\u4FE1\u606F";
    const QJST = "\u67E5\u770B\u5224\u9898\u72B6\u6001";
}
//# sourceMappingURL=callsymbol.d.ts.map