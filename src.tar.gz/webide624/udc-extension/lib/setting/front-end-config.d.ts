export declare const AI1DOC = "http://linklab.tinylink.cn/static/doc/sidebar1.html";
export declare const AI2DOC = "http://linklab.tinylink.cn/static/doc/sidebar2.html";
export declare const AI3DOC = "http://linklab.tinylink.cn/static/doc/sidebar3.html";
export declare const MODEL_DOWNLOAD_URL = "ws://47.98.249.190:8005/";
export declare const DETAIL_ISSUE_URL: string;
export declare const LINK_LAB_HOMEPAGE_URL: string;
export declare const QUIZE_JUDGE_URL: string;
export declare const CHOICE_JUDGE_URL = "http://judge.tinylink.cn/quiz/choices/judge";
export declare const USER_INFO_URL: string;
export declare const VIEW_DETAIL_URL: string;
export declare const VIDEO_URL = "http://linklab.tinylink.cn/";
export declare const QUIZ_CONTENT_URL = "http://judge.tinylink.cn/quiz/content";
export declare const PROBLEM_STATUS_URL: string;
export declare const MULTIPLY_PROBLEM_STATUS_URL: string;
export declare const FINISH_URL: string;
//# sourceMappingURL=front-end-config.d.ts.map