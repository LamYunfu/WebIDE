export {};
//# sourceMappingURL=readtest.d.ts.map