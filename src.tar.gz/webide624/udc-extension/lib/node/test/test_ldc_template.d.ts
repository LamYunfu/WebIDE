import "reflect-metadata";
//# sourceMappingURL=test_ldc_template.d.ts.map