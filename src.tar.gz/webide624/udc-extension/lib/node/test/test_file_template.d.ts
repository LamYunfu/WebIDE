import "reflect-metadata";
//# sourceMappingURL=test_file_template.d.ts.map