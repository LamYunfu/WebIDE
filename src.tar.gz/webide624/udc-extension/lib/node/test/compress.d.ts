import "reflect-metadata";
//# sourceMappingURL=compress.d.ts.map