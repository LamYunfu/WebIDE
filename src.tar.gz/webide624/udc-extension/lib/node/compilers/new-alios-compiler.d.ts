import { FileMapper } from "./../util/filemapper";
import { UdcTerminal } from "./../util/udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
import { DistributedCompiler } from "./distributedcompiler";
export declare class NewAliosCompiler {
    protected readonly udc: UdcTerminal;
    protected readonly fm: FileMapper;
    rootDir: RootDirPath;
    dc: DistributedCompiler;
    constructor(udc: UdcTerminal, fm: FileMapper, rootDir: RootDirPath, dc: DistributedCompiler);
    postNameAndType(pid: string): Promise<"err" | "scc">;
    compileSingleFile(dirName: string, item: string, pid: string, model: string): Promise<boolean>;
    postSingleSrcFile(projectName: string, role: string, pid: string): Promise<unknown>;
}
//# sourceMappingURL=new-alios-compiler.d.ts.map