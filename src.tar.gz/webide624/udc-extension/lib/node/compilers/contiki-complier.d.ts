import { FileMapper } from "../util/filemapper";
import { UdcTerminal } from "../util/udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
import { DistributedCompiler } from "./distributedcompiler";
export declare class NewContikiCompiler {
    protected readonly udc: UdcTerminal;
    protected readonly fm: FileMapper;
    rootDir: RootDirPath;
    protected readonly dc: DistributedCompiler;
    constructor(udc: UdcTerminal, fm: FileMapper, rootDir: RootDirPath, dc: DistributedCompiler);
    postNameAndType(pid: string): Promise<"err" | "scc">;
    compileSingleFile(dirName: string, item: string, pid: string): Promise<boolean>;
    postSingleSrcFile(projectName: string, role: string, pid: string): Promise<unknown>;
}
//# sourceMappingURL=contiki-complier.d.ts.map