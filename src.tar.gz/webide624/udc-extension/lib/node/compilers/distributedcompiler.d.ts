import { UdcTerminal } from "../util/udc-terminal";
import { CallInfoStorer } from "../util/callinfostorer";
export declare class DistributedCompiler {
    readonly udc: UdcTerminal;
    readonly cis: CallInfoStorer;
    constructor(udc: UdcTerminal, cis: CallInfoStorer);
    outputResult(mes: string, type?: string): void;
    upload(path: string, boardType: string, compileType: string): Promise<string>;
    waitCompileFinish(path: string, output: string): Promise<string>;
    getHexFile(path: string, output: string): Promise<string>;
    compile(path: string, hexPath: string, boardType: string, compileType: string): Promise<boolean>;
}
//# sourceMappingURL=distributedcompiler.d.ts.map