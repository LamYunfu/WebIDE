import * as FormData from "form-data";
import { UdcTerminal } from "../util/udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
import { CallInfoStorer } from "../util/callinfostorer";
export declare class UdcCompiler {
    protected readonly udc: UdcTerminal;
    rootDir: RootDirPath;
    readonly cis: CallInfoStorer;
    constructor(udc: UdcTerminal, rootDir: RootDirPath, cis: CallInfoStorer);
    DEBUG: boolean;
    tinyLinkAPIs: {
        [key: string]: string;
    };
    cookie: string;
    getHexNmame(fn: string): string;
    postSrcFile(pid: string, roleName?: string): Promise<string>;
    postData(host: string, port: string, path: string, data: any): Promise<string>;
    submitForm(fm: FormData, hostname: string, port: string, path: string, method: string): Promise<string>;
    setCookie(cookie: string): boolean;
    outputResult(res: string, types?: string): void;
}
//# sourceMappingURL=udc-compiler.d.ts.map