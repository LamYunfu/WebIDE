export declare type BoardInfo = {
    possibleBoardName: string;
    boardType: string;
    compilerType: string;
};
export declare class BoardAndCompileType {
    esp32xx: BoardInfo;
    esp32: BoardInfo;
    devkit: BoardInfo;
    telosb: BoardInfo;
    telosb1: BoardInfo;
    cc2650: BoardInfo;
    rsp3: BoardInfo;
    rsp: BoardInfo;
    mega2560: BoardInfo;
    arduinouno: BoardInfo;
    stm32: BoardInfo;
    getCompileType(boardType: string): string | undefined;
    getRealBoardType(boardType: string): any;
}
//# sourceMappingURL=boardtocompilemethod.d.ts.map