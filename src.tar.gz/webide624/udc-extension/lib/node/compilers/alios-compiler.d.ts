import * as FormData from "form-data";
import { UdcTerminal } from "../util/udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
export declare class AliosCompiler {
    rootDir: RootDirPath;
    protected readonly udc: UdcTerminal;
    constructor(rootDir: RootDirPath, udc: UdcTerminal);
    DEBUG: boolean;
    cookie: string;
    AliosAPIs: {
        [key: string]: string;
    };
    setDownloadHexPathName(projectName: string, boardType: string): void;
    getHexNmame(fn: string): string;
    devs: string[];
    extractHex(index: number, useQueue: boolean, dirName: string, pid: string): Promise<string | undefined>;
    postNameAndType(pid: string): Promise<void>;
    postRoleSrcFile(dirName: string, srcFileDirName: string): Promise<string>;
    postData(host: string, port: string, path: string, data: any): Promise<string>;
    submitForm(fm: FormData, hostname: string, port: string, path: string, method: string): Promise<string>;
    setCookie(cookie: string): boolean;
    outputResult(res: string, types?: string): void;
}
//# sourceMappingURL=alios-compiler.d.ts.map