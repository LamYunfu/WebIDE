import { NewContikiCompiler } from "./contiki-complier";
import { NewAliosCompiler } from "./new-alios-compiler";
import { UdcTerminal } from "../util/udc-terminal";
import { UdcCompiler } from "./udc-compiler";
import { RaspeberryGccCompiler } from "./raspberry-gcc-compiler";
import { RootDirPath } from "../../setting/backend-config";
import { FileMapper } from "../util/filemapper";
import { DistributedCompiler } from "./distributedcompiler";
import { BoardAndCompileType } from "./boardtocompilemethod";
export declare class Compiler {
    readonly bat: BoardAndCompileType;
    protected readonly udc: UdcTerminal;
    protected readonly fm: FileMapper;
    protected readonly dc: DistributedCompiler;
    protected readonly udcCompiler: UdcCompiler;
    protected readonly newAliosCompiler: NewAliosCompiler;
    protected readonly newContikiCompiler: NewContikiCompiler;
    protected readonly udcTerminal: UdcTerminal;
    protected readonly rgc: RaspeberryGccCompiler;
    rootDir: RootDirPath;
    constructor(bat: BoardAndCompileType, udc: UdcTerminal, fm: FileMapper, dc: DistributedCompiler, udcCompiler: UdcCompiler, newAliosCompiler: NewAliosCompiler, newContikiCompiler: NewContikiCompiler, udcTerminal: UdcTerminal, rgc: RaspeberryGccCompiler, rootDir: RootDirPath);
    linkEdgeCompile(pid: string, index: string): Promise<void>;
    compile(pid: string): Promise<"err" | "scc" | "fail">;
    compileSingleFile(pid: string, fn: string): Promise<"scc" | "fail">;
    compileNotTinyLink(pid: string): Promise<"err" | "scc">;
}
//# sourceMappingURL=compiler.d.ts.map