import { FileMapper } from "./../util/filemapper";
import * as FormData from "form-data";
import { RootDirPath } from "../../setting/backend-config";
import { CompilerInterFace } from "./compilerInterface";
import { UdcTerminal } from "../util/udc-terminal";
import { DistributedCompiler } from "./distributedcompiler";
export declare class RaspeberryGccCompiler implements CompilerInterFace {
    protected readonly udc: UdcTerminal;
    protected readonly fm: FileMapper;
    rootDir: RootDirPath;
    protected readonly dc: DistributedCompiler;
    constructor(udc: UdcTerminal, fm: FileMapper, rootDir: RootDirPath, dc: DistributedCompiler);
    outputResult(str: string, type?: string): void;
    archiveFile(fileDir: string, outputPath: string): Promise<string>;
    config(data: any): Promise<string>;
    upload(fm: FormData): Promise<string>;
    getFile(data: any, filePath: string): Promise<string>;
    compile(fileDir: string, outputPath: string): Promise<string>;
    processFreeCoding(pid: string): Promise<boolean | "err">;
}
//# sourceMappingURL=raspberry-gcc-compiler.d.ts.map