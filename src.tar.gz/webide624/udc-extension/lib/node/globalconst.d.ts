export declare const hexFileDir = "hexFiles";
export declare const getCompilerType: (model: string) => string;
export declare const getBoardType: (model: string) => string;
//# sourceMappingURL=globalconst.d.ts.map