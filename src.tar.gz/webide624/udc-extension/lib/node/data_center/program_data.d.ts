export declare class QueueBurnElem {
    model: string;
    waitingId: string;
    runtime: number | undefined;
    address: string | undefined;
    filehash: string | undefined;
}
export declare class AdhocBurnElem {
    clientId: string | undefined;
    devPort: string | undefined;
    waitingId: string;
    runtime: number | undefined;
    address: string | undefined;
    filehash: string | undefined;
}
export declare class Skeleton {
    type: "QUEUE" | "ADHOC";
    groupId: string;
    pid: string | undefined;
    program: QueueBurnElem[] | AdhocBurnElem[] | undefined;
}
export declare class ProgramBurnDataFactory {
    produceQueueBurnElem(): QueueBurnElem;
    produceAdhocBurnElem(): AdhocBurnElem;
    produceQueueSketon(): Skeleton;
    produceAdhocSketon(): Skeleton;
}
//# sourceMappingURL=program_data.d.ts.map