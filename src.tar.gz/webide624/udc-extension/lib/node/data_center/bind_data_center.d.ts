import { interfaces } from "inversify";
export declare function bindDataCenter(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_data_center.d.ts.map