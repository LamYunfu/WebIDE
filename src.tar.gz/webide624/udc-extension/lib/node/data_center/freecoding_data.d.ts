declare class QueueBurnDetail {
    model: string | null;
    runtime: number | null;
    address: string | null;
}
declare class AdhocBurnDetail {
    clientId: string | null;
    devPort: string | null;
    runtime: number | null;
    address: string | null;
}
declare class QueueDetail {
    projectName: string | null;
    compileType: string | null;
    boardType: string | null;
    burnType: string | null;
    program: QueueBurnDetail | null;
}
declare class AdhocDetail {
    projectName: string | null;
    compileType: string | null;
    boardType: string | null;
    burnType: string | null;
    program: AdhocBurnDetail | null;
}
export declare class QueueSetting {
    version: string | null;
    usage: string | null;
    hexFileDir: string | null;
    serverType: string | null;
    projects: QueueDetail[] | null;
}
export declare class AdhocSetting {
    version: string | null;
    usage: string | null;
    hexFileDir: string | null;
    serverType: string | null;
    projects: AdhocDetail[] | null;
}
export declare class FreeCodingData {
    deviceUsage: string;
    hexFileDir: string;
    projects: {
        [key: string]: any;
    }[];
}
export {};
//# sourceMappingURL=freecoding_data.d.ts.map