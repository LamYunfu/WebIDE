export declare type LoginType = "adhoc" | "queue" | string;
export declare class ProjectData {
    protected _projectRootDir: string;
    protected _pid: string;
    protected _loginType: LoginType;
    protected _serverType: string;
    protected _subProjectArray: string[];
    protected _subModelTypes: string[];
    protected _subBoardTypes: string[];
    protected _subCompileTypes: string[];
    protected _address: string[];
    protected _fileHash: string[];
    protected _subTimeouts: number[];
    protected _subClientId: string[];
    protected _subClientPort: string[];
    protected _subWaitingIds: string[];
    protected _subHexFileDirs: string[];
    protected _ppid: string;
    loginType: LoginType;
    pid: string;
    ppid: string;
    serverType: string;
    projectRootDir: string;
    subProjectArray: string[];
    address: string[];
    subCompileTypes: string[];
    subModelTypes: string[];
    subTimeouts: number[];
    subWaitingIds: string[];
    subHexFileDirs: string[];
    subBoardTypes: string[];
    fileHash: string[];
    subClientId: string[];
    subClientPort: string[];
}
//# sourceMappingURL=project_data.d.ts.map