export declare class UserInfo {
    private _username;
    private _passwd;
    private _tinyname;
    private _cookie;
    isValid(): boolean;
    username: string;
    passwd: string;
    tinyname: string;
    cookie: string;
}
//# sourceMappingURL=user_info.d.ts.map