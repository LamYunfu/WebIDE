import { ProjectData } from "./project_data";
export declare class MultiProjectData {
    projectID: string | null;
    rootDir: string;
    projectType: string;
    dataMap: {
        [pid: string]: ProjectData;
    };
}
//# sourceMappingURL=multi_project_data.d.ts.map