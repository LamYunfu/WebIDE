import { DataService } from './../../services/data_service/data_service';
import { TinyLinkCompiler } from './../../services/compiler/tiny_link_compiler';
import { UserInfo } from "../../data_center/user_info";
import { ProjectData } from "../../data_center/project_data";
import { LdcClientControllerInterface } from "../../services/ldc/interfaces/ldc_client_controller_interface";
import { LdcShellInterface } from "../../services/ldc_shell/interfaces/ldc_shell_interface";
import { ProgramBurnDataFactory } from "../../data_center/program_data";
import { LdcFileServer } from "../../services/ldc_file_server/ldc_file_server";
import { ProgramerInterface } from "../../services/programers/interfaces/programer_interface";
import { DistributedCompiler } from "../../services/compiler/ds_compiler";
import { MultiProjectData } from "../../data_center/multi_project_data";
export declare class ExperimentController {
    protected userInfo: UserInfo;
    protected projectData: ProjectData;
    protected queueProgramer: ProgramerInterface;
    protected adhocProgramer: ProgramerInterface;
    protected dsc: DistributedCompiler;
    protected programBurnDataFactory: ProgramBurnDataFactory;
    protected ldcFileServer: LdcFileServer;
    protected lcc: LdcClientControllerInterface;
    protected dService: DataService;
    protected ldcShell: LdcShellInterface;
    protected multiProjectData: MultiProjectData;
    protected tinyLinkCompiler: TinyLinkCompiler;
    constructor(userInfo: UserInfo, projectData: ProjectData, queueProgramer: ProgramerInterface, adhocProgramer: ProgramerInterface, dsc: DistributedCompiler, programBurnDataFactory: ProgramBurnDataFactory, ldcFileServer: LdcFileServer, lcc: LdcClientControllerInterface, dService: DataService, ldcShell: LdcShellInterface, multiProjectData: MultiProjectData, tinyLinkCompiler: TinyLinkCompiler);
    submitQueue(): Promise<boolean>;
    submitAdhoc(): Promise<boolean>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=experiment_controller.d.ts.map