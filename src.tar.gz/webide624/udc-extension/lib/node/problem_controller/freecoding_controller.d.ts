import { FreeCodingDataService } from './../services/data_service/freecoding_data_service';
import { DataService } from './../services/data_service/data_service';
export declare class FreeCodingController {
    protected dService: DataService;
    protected freeCodingDataService: FreeCodingDataService;
    constructor(dService: DataService, freeCodingDataService: FreeCodingDataService);
}
//# sourceMappingURL=freecoding_controller.d.ts.map