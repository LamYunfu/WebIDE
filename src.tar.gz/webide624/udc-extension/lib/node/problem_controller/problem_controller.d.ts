import { LdcClientControllerInterface } from './../services/ldc/interfaces/ldc_client_controller_interface';
import { EventCenter } from './../services/tools/event_center';
import { FileTemplate } from './../services/file_template/file_template';
import { FileOpener } from './../services/opener/file_openner';
import { LdcShellInterface } from './../services/ldc_shell/interfaces/ldc_shell_interface';
import { DistributedCompiler } from './../services/compiler/ds_compiler';
import { ProjectData } from './../data_center/project_data';
import { DataService } from './../services/data_service/data_service';
import { ExperimentController } from './experiment_controller/experiment_controller';
import { MultiProjectData } from '../data_center/multi_project_data';
export declare class ProblemController {
    protected dataService: DataService;
    protected mpData: MultiProjectData;
    protected dService: DataService;
    protected pData: ProjectData;
    protected dc: DistributedCompiler;
    protected experimentController: ExperimentController;
    protected fileOpener: FileOpener;
    protected fileTemplate: FileTemplate;
    protected lcc: LdcClientControllerInterface;
    protected ldcShell: LdcShellInterface;
    protected eventCenter: EventCenter;
    private _lock;
    constructor(dataService: DataService, mpData: MultiProjectData, dService: DataService, pData: ProjectData, dc: DistributedCompiler, experimentController: ExperimentController, fileOpener: FileOpener, fileTemplate: FileTemplate, lcc: LdcClientControllerInterface, ldcShell: LdcShellInterface, eventCenter: EventCenter);
    init(info: string): Promise<void>;
    acquireLock(): boolean;
    unLock(): void;
    submit(pid: string): Promise<void>;
    checkConnection(): Promise<boolean>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=problem_controller.d.ts.map