import { interfaces } from "inversify";
export declare function bindProblemControllers(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_problem_controller.d.ts.map