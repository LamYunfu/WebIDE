import * as WebSocket from "ws";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
import { EventCenter } from "../tools/event_center";
import { FileCompressor } from "../tools/file_compressor";
import { Packet } from "../ldc/packet";
export declare class TinySim {
    readonly ldcShell: LdcShellInterface;
    readonly cis: CallInfoStorerInterface;
    protected events: EventCenter;
    protected fileCompressor: FileCompressor;
    protected pkt: Packet;
    constructor(ldcShell: LdcShellInterface, cis: CallInfoStorerInterface, events: EventCenter, fileCompressor: FileCompressor, pkt: Packet);
    tinySimClient: WebSocket | undefined;
    postSimFile(pid: string, simFilePath: string): Promise<void>;
    connectSimServer(server: string): Promise<boolean>;
    outputResult(res: string, type?: string): void;
    virtualSubmit(serverPath: string, srcDir: string): Promise<boolean>;
}
//# sourceMappingURL=tinysim.d.ts.map