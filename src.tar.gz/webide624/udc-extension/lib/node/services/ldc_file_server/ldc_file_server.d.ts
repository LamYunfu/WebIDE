import { ProjectData } from './../../data_center/project_data';
import { interfaces } from "inversify";
import { CallInfoStorer } from "../log/call_info_storer";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
export declare function bindLdcFileServer(bind: interfaces.Bind): void;
export declare class LdcFileServer {
    protected cis: CallInfoStorer;
    protected projectData: ProjectData;
    protected ldcShell: LdcShellInterface;
    constructor(cis: CallInfoStorer, projectData: ProjectData, ldcShell: LdcShellInterface);
    fileUpload(filepath: string, index: string): Promise<boolean>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=ldc_file_server.d.ts.map