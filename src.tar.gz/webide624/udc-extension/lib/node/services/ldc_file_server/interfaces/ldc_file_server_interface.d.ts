export interface LdcFileServerInterface {
}
//# sourceMappingURL=ldc_file_server_interface.d.ts.map