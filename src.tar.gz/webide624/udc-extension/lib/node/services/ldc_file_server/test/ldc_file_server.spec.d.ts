import "reflect-metadata";
//# sourceMappingURL=ldc_file_server.spec.d.ts.map