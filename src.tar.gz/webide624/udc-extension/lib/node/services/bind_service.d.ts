import { interfaces } from "inversify";
export declare function bindServices(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_service.d.ts.map