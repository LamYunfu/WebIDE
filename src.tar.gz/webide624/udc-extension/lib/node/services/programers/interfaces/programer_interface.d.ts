export declare const ProgramerInterface: unique symbol;
export interface ProgramerInterface {
    burn(): Promise<boolean>;
}
//# sourceMappingURL=programer_interface.d.ts.map