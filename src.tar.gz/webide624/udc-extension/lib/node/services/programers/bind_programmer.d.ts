import { interfaces } from "inversify";
export declare function bindProgramers(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_programmer.d.ts.map