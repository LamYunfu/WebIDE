import { DataService } from './../data_service/data_service';
import { ProgramerInterface } from "./interfaces/programer_interface";
import { ProjectData } from "../../data_center/project_data";
import { UserInfo } from "../../data_center/user_info";
import { LdcClientControllerInterface } from "../ldc/interfaces/ldc_client_controller_interface";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { ProgramBurnDataFactory } from "../../data_center/program_data";
import { DistributedCompiler } from "../compiler/ds_compiler";
export declare class AdhocProgramer implements ProgramerInterface {
    protected dService: DataService;
    protected projectData: ProjectData;
    protected userInfo: UserInfo;
    protected lcc: LdcClientControllerInterface;
    protected ldcShell: LdcShellInterface;
    protected dsc: DistributedCompiler;
    protected programBurnDataFactory: ProgramBurnDataFactory;
    constructor(dService: DataService, projectData: ProjectData, userInfo: UserInfo, lcc: LdcClientControllerInterface, ldcShell: LdcShellInterface, dsc: DistributedCompiler, programBurnDataFactory: ProgramBurnDataFactory);
    burn(): Promise<boolean>;
}
//# sourceMappingURL=adhoc_progamer.d.ts.map