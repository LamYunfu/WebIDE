import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { ServerConnectionInterface } from "../ldc/interfaces/server_connection_interface";
import { EventCenter } from "../tools/event_center";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
export declare class QueryService {
    protected readonly ldcShell: LdcShellInterface;
    protected readonly sc: ServerConnectionInterface;
    protected cevents: EventCenter;
    protected cis: CallInfoStorerInterface;
    constructor(ldcShell: LdcShellInterface, sc: ServerConnectionInterface, cevents: EventCenter, cis: CallInfoStorerInterface);
    outputResult(res: string, type?: string): void;
    getIdleDeviceCount(model: string): Promise<void>;
    getSSHCMD(device: string): void;
    getLastWebUrl(lastCommitDevice: {
        device: string;
        timeMs: number;
    }): void;
    getSocket(lastCommitDevice: {
        device: string;
        timeMs: number;
    }): void;
}
//# sourceMappingURL=query_service.d.ts.map