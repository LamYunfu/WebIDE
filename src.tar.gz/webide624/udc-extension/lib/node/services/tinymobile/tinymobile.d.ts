import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
export declare class OnelinkService {
    protected ldcShell: LdcShellInterface;
    protected cis: CallInfoStorerInterface;
    ready: boolean;
    mobileFile: string;
    tokenPath: string;
    projectInfo: {
        projectName: string;
        token: string;
    };
    constructor(ldcShell: LdcShellInterface, cis: CallInfoStorerInterface);
    prepare(currentDir: string): void;
    isReady(): boolean;
    getProjectInfo(tokenPath: string, projectName: string): {
        token: string;
        projectName: string;
    } | null;
    createProject(projectName: string, pid: string): Promise<boolean>;
    compileDevice(): Promise<boolean>;
    createMobileApp(mobileFile: string, projectName: string): Promise<boolean>;
    processBackValue(backValue: any): boolean;
    complileMobile(): Promise<boolean>;
    update(token: string, projectName: string, mobileFile: string, tokenPath: string): Promise<boolean>;
    openMobile(): Promise<void>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=tinymobile.d.ts.map