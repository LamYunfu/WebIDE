import { UdcClient } from './../../../../common/udc-watcher';
export declare const LdcShellInterface: unique symbol;
export interface LdcShellInterface {
    outputResult: (res: string, types: string) => void;
    executeFrontCmd: (cmd: {
        name: string;
        passwd: string;
    }) => void;
    setUdcClient: (x: UdcClient) => void;
}
export declare class DefaultLdcShell implements LdcShellInterface {
    setUdcClient(x: UdcClient): void;
    outputResult(res: string, types: string): void;
    executeFrontCmd(cmd: {
        name: string;
        passwd: string;
    }): void;
}
//# sourceMappingURL=ldc_shell_interface.d.ts.map