import { UdcClient } from "../../../common/udc-watcher";
import { interfaces } from "inversify";
export declare function bindLdcShell(bind: interfaces.Bind): void;
export declare class LdcShell {
    protected _udcClient: UdcClient | undefined;
    constructor();
    udcClient: UdcClient | undefined;
    setUdcClient(x: UdcClient): void;
    outputResult(res: string, types?: string): void;
    executeFrontCmd(cmd: {
        name: string;
        passwd: string;
    }): void;
}
//# sourceMappingURL=ldc_shell.d.ts.map