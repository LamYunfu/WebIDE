import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
export declare class LiteralAnalysis {
    protected ldcShell: LdcShellInterface;
    constructor(ldcShell: LdcShellInterface);
    literalAnalysis(pid: string, path: string): void;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=literal_analysis.d.ts.map