import { UserInfo } from "../../data_center/user_info";
import { interfaces } from "inversify";
export declare function bindCallInfoStorer(bind: interfaces.Bind): void;
export declare class CallInfoStorer {
    protected user: UserInfo;
    constructor(user: UserInfo);
    storeCallInfoInstantly(info: string, api: string, severity?: number): void;
    storeCallInfoLatter(time: string, info: string, api: string, severity?: number): void;
}
//# sourceMappingURL=call_info_storer.d.ts.map