/// <reference types="node" />
export declare class FileCompressor {
    compress(srcPath: string, targetPath: string): Promise<boolean>;
    unfold(srcPath: string, entryName: string, targetPath: string): Promise<boolean>;
    unfoldAll(srcPath: string, targetPath: string): Promise<void>;
    getHash(rb: string | Buffer, type?: string): Promise<string>;
    generateTempFilePath(): string;
}
//# sourceMappingURL=file_compressor.d.ts.map