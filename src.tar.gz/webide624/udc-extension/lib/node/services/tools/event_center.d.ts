/// <reference types="node" />
import { EventEmitter } from "events";
export declare class EventCenter extends EventEmitter {
    waitEventNms(evName: string, timeout: number): Promise<boolean>;
    waitNmsForBackValue<T>(evName: string, timeout: number): Promise<T>;
}
//# sourceMappingURL=event_center.d.ts.map