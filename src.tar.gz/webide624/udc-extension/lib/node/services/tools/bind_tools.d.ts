import { interfaces } from "inversify";
export declare function bindTools(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_tools.d.ts.map