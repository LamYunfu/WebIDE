import "reflect-metadata";
//# sourceMappingURL=main.d.ts.map