import * as WebSocket from "ws";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { FileCompressor } from "../tools/file_compressor";
import { Packet } from "../ldc/packet";
export declare class ModelTrainer {
    protected ldcShell: LdcShellInterface;
    protected fileCompressor: FileCompressor;
    protected pkt: Packet;
    ws: WebSocket | undefined;
    constructor(ldcShell: LdcShellInterface, fileCompressor: FileCompressor, pkt: Packet);
    connect(trainServer: string): Promise<boolean | undefined>;
    train(srcPath: string, trainServer: string): Promise<boolean>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=model_trainer.d.ts.map