export declare const ModelTrainerInterface: unique symbol;
export interface ModelTrainerInterface {
}
//# sourceMappingURL=mode_trainer_interface.d.ts.map