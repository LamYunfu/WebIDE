export declare const FileTemplateInterface: unique symbol;
export interface FileTemplateInterface {
    buildProblemFileStructure: (ppid: string, targetPath: string) => Promise<boolean>;
}
//# sourceMappingURL=file_template_interface.d.ts.map