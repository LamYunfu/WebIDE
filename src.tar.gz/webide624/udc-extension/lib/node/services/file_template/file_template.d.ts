import { MultiProjectData } from './../../data_center/multi_project_data';
import { CallInfoStorer } from "../log/call_info_storer";
import { interfaces } from "inversify";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { FileTemplateInterface } from "./interfaces/file_template_interface";
export declare function bindFileTemplate(bind: interfaces.Bind): void;
export declare class FileTemplate implements FileTemplateInterface {
    protected cis: CallInfoStorer;
    protected ldcShell: LdcShellInterface;
    protected mData: MultiProjectData;
    constructor(cis: CallInfoStorer, ldcShell: LdcShellInterface, mData: MultiProjectData);
    buildAllProjects(): Promise<void>;
    buildProblemFileStructure(ppid: string, targetPath: string): Promise<boolean>;
    createDirStructure(cpath: string, res: any): void;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=file_template.d.ts.map