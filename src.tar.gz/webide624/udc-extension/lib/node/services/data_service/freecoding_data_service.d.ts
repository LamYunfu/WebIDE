import { AdhocSetting, QueueSetting } from "../../data_center/freecoding_data";
import { ProjectData } from "../../data_center/project_data";
import { MultiProjectData } from "../../data_center/multi_project_data";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
export declare class FreeCodingDataService {
    protected multiProjectData: MultiProjectData;
    protected ldcShell: LdcShellInterface;
    constructor(multiProjectData: MultiProjectData, ldcShell: LdcShellInterface);
    parseProjectDataFromFile(pd: ProjectData): void;
    convertSettingToProjectData(st: AdhocSetting | QueueSetting, pd: ProjectData): boolean;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=freecoding_data_service.d.ts.map