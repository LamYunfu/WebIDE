import { interfaces } from 'inversify';
export declare function bindDataService(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_data_service.d.ts.map