import { LdcData } from './../../data_center/ldc_data';
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
import { ProjectData } from "../../data_center/project_data";
import { MultiProjectData } from "../../data_center/multi_project_data";
export declare class DataService {
    protected ldcData: LdcData;
    readonly ldcShell: LdcShellInterface;
    readonly cis: CallInfoStorerInterface;
    protected projectData: ProjectData;
    protected multiProjectData: MultiProjectData;
    constructor(ldcData: LdcData, ldcShell: LdcShellInterface, cis: CallInfoStorerInterface, projectData: ProjectData, multiProjectData: MultiProjectData);
    outputResult(res: string, type?: string): void;
    needReconnectServer(): boolean;
    initDataMapFromFrontEnd(info: string): Promise<boolean>;
    copyDataFromDataMap(pid: string): Promise<boolean>;
    copyLdcDataFromData(): void;
    refreshMultiData(): void;
    private generate16ByteNumber;
    generateWaitingID(): string;
}
//# sourceMappingURL=data_service.d.ts.map