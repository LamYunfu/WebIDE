import "reflect-metadata";
export declare class a {
    a: string;
    print(): void;
}
export declare class b {
    protected aa: a;
    constructor(aa: a);
    a: string;
    print(): void;
    assign(): void;
}
//# sourceMappingURL=main.d.ts.map