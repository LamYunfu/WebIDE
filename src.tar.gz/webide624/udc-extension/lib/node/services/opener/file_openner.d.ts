import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
export declare class FileOpener {
    protected ldcShell: LdcShellInterface;
    constructor(ldcShell: LdcShellInterface);
    openFile(path: string): void;
    openWorkspace(path: string): void;
}
//# sourceMappingURL=file_openner.d.ts.map