import { interfaces } from 'inversify';
export declare function bindOpener(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_opener.d.ts.map