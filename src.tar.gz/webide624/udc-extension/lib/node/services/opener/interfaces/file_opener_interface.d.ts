export interface FileOpenerInterface {
    openFile(): void;
}
//# sourceMappingURL=file_opener_interface.d.ts.map