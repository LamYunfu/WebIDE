import { FileCompressor } from './../tools/file_compressor';
import { interfaces } from "inversify";
import { CallInfoStorer } from "../log/call_info_storer";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { ProjectData } from "../../data_center/project_data";
export declare function bindDistributedCompiler(bind: interfaces.Bind): void;
export declare class DistributedCompiler {
    readonly ldcShell: LdcShellInterface;
    readonly cis: CallInfoStorer;
    readonly projectData: ProjectData;
    readonly fileCompressor: FileCompressor;
    constructor(ldcShell: LdcShellInterface, cis: CallInfoStorer, projectData: ProjectData, fileCompressor: FileCompressor);
    outputResult(mes: string, type?: string): void;
    upload(path: string, boardType: string, compileType: string, projectIndex: string): Promise<string>;
    waitCompileFinish(path: string, output: string): Promise<string>;
    queryCompileStatus(path: string, output: string): Promise<string>;
    compile(path: string, hexPath: string, boardType: string, compileType: string, projectIndex: string): Promise<boolean>;
}
//# sourceMappingURL=ds_compiler.d.ts.map