import { LdcFileServer } from './../ldc_file_server/ldc_file_server';
import { DataService } from './../data_service/data_service';
import { interfaces } from "inversify";
import { CallInfoStorer } from "../log/call_info_storer";
import { UserInfo } from "../../data_center/user_info";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { FileCompressor } from "../tools/file_compressor";
export declare function bindTinyLinkCompiler(bind: interfaces.Bind): void;
export declare class TinyLinkCompiler {
    readonly cis: CallInfoStorer;
    protected uif: UserInfo;
    protected ldcShell: LdcShellInterface;
    protected fileCompressor: FileCompressor;
    protected dService: DataService;
    protected ldcFileServer: LdcFileServer;
    constructor(cis: CallInfoStorer, uif: UserInfo, ldcShell: LdcShellInterface, fileCompressor: FileCompressor, dService: DataService, ldcFileServer: LdcFileServer);
    DEBUG: boolean;
    tinyLinkAPIs: {
        hostname: string;
        port: string;
        srcPostPath: string;
    };
    readonly cookie: string;
    outputResult(mes: string, type?: string): void;
    processZipFile(zipPath: string, inst: string, tinyapp: string, index: string): Promise<boolean>;
    compile(srcPath: string, index: string): Promise<boolean>;
}
//# sourceMappingURL=tiny_link_compiler.d.ts.map