import { interfaces } from "inversify";
export declare function bindCompilers(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_compiler.d.ts.map