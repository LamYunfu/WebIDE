import { interfaces } from "inversify";
export declare function bindLdcClientController(bind: interfaces.Bind): void;
//# sourceMappingURL=bind_ldc.d.ts.map