import { LdcClientControllerInterface } from "./interfaces/ldc_client_controller_interface";
import { ControllerConnectionInterface } from "./interfaces/controller_connection_interface";
import { ServerConnectionInterface } from "./interfaces/server_connection_interface";
import { LdcData } from "../../data_center/ldc_data";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { EventCenter } from "../tools/event_center";
import { Skeleton } from "../../data_center/program_data";
export declare class LdcClientController implements LdcClientControllerInterface {
    protected ldd: LdcData;
    protected cc: ControllerConnectionInterface;
    protected sc: ServerConnectionInterface;
    protected ldcShell: LdcShellInterface;
    protected ec: EventCenter;
    constructor(ldd: LdcData, cc: ControllerConnectionInterface, sc: ServerConnectionInterface, ldcShell: LdcShellInterface, ec: EventCenter);
    isConnected(): boolean;
    disconnect(): Promise<boolean>;
    connect(): Promise<boolean>;
    outputResult(res: string, type?: string): void;
    burn(ske: Skeleton): Promise<boolean>;
}
//# sourceMappingURL=ldc_client_controller.d.ts.map