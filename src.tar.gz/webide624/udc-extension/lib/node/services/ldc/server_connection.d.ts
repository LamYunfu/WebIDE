/// <reference types="node" />
import * as net from "net";
import { HalfPackProcess } from "./half-pkt-process";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { Packet } from "../../util/packet";
import { CallInfoStorer } from "../log/call_info_storer";
import { EventCenter } from "../tools/event_center";
import { ServerConnectionInterface } from "./interfaces/server_connection_interface";
import { LdcData } from "../../data_center/ldc_data";
import { interfaces } from "inversify";
import { Skeleton } from "../../data_center/program_data";
export declare function bindServerConnectionController(bind: interfaces.Bind): void;
export declare class ServerConnection implements ServerConnectionInterface {
    protected hpp: HalfPackProcess;
    protected pkt: Packet;
    protected cis: CallInfoStorer;
    protected events: EventCenter;
    protected ldd: LdcData;
    protected ldcShell: LdcShellInterface;
    udcServerClient: net.Socket | undefined;
    dev_list: {
        [key: string]: number;
    } | undefined;
    logEnable: boolean;
    cmd_excute_return: string;
    cmd_excute_state: string;
    constructor(hpp: HalfPackProcess, pkt: Packet, cis: CallInfoStorer, events: EventCenter, ldd: LdcData, ldcShell: LdcShellInterface);
    isConnected(): boolean;
    disconnect(): Promise<boolean>;
    connect_to_server(server_ip: string, server_port: number, certificate: string, pid: string, uuid: string, token: string): Promise<boolean>;
    outputResult(res: string, type?: string): void;
    sendPacket(type: string, content: string): void;
    onUdcServerData: (data: Buffer) => void;
    program(ske: Skeleton): Promise<boolean>;
}
//# sourceMappingURL=server_connection.d.ts.map