import { Packet } from "./packet";
import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { ControllerConnectionInterface } from "./interfaces/controller_connection_interface";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
import { interfaces } from "inversify";
export declare function bindControllerConnection(bind: interfaces.Bind): void;
export declare class LdcControllerConnection implements ControllerConnectionInterface {
    protected pkt: Packet;
    protected cis: CallInfoStorerInterface;
    protected ldcShell: LdcShellInterface;
    constructor(pkt: Packet, cis: CallInfoStorerInterface, ldcShell: LdcShellInterface);
    login_and_get_server(uuid: string, login_type: string, model: string): Promise<Array<any>>;
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=controller_connection.d.ts.map