import { Skeleton } from "../../../data_center/program_data";
export declare const ServerConnectionInterface: unique symbol;
export interface ServerConnectionInterface {
    connect_to_server(server_ip: string, server_port: number, certificate: string, pid: string, uuid: string, token: string): Promise<boolean>;
    disconnect(): Promise<boolean>;
    isConnected(): boolean;
    program(ske: Skeleton): Promise<boolean>;
    sendPacket(type: string, content: string): void;
}
//# sourceMappingURL=server_connection_interface.d.ts.map