import { Skeleton } from "../../../data_center/program_data";
export declare const LdcClientControllerInterface: unique symbol;
export interface LdcClientControllerInterface {
    connect: () => Promise<boolean>;
    disconnect: () => Promise<boolean>;
    isConnected: () => boolean;
    burn: (ske: Skeleton) => Promise<boolean>;
}
//# sourceMappingURL=ldc_client_controller_interface.d.ts.map