export declare const ControllerConnectionInterface: unique symbol;
export interface ControllerConnectionInterface {
    login_and_get_server: (uuid: string, login_type: string, model: string) => Promise<Array<any>>;
}
//# sourceMappingURL=controller_connection_interface.d.ts.map