/// <reference types="node" />
import { EventEmitter } from "events";
export declare class HalfPackProcess extends EventEmitter {
    constructor();
    maxSize: number;
    dataBuffer: Buffer;
    cursorStart: number;
    cursorEnd: number;
    currentDataSize: number;
    callNum: number;
    putData(inData: Buffer): void;
    acquireData(): void;
}
//# sourceMappingURL=half-pkt-process.d.ts.map