import { LdcShellInterface } from "../ldc_shell/interfaces/ldc_shell_interface";
import { CallInfoStorerInterface } from "../log/interfaces/call_storer_interface";
export declare class Demo {
    readonly ldcShell: LdcShellInterface;
    readonly cis: CallInfoStorerInterface;
    constructor(ldcShell: LdcShellInterface, cis: CallInfoStorerInterface);
    outputResult(res: string, type?: string): void;
}
//# sourceMappingURL=demo.d.ts.map