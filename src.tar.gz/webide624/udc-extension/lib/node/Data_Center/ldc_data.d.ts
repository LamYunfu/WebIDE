export declare type LastCommitDevice = {
    timeMs: number;
    device: string;
} | undefined;
export declare class LdcData {
    private _uuid;
    private _serverType;
    private _loginType;
    private _serverTimeout;
    private _waitingIds;
    private _projectNames;
    private _clientIds;
    private _ports;
    private _ldcState;
    private _pid;
    private _lastCommitDevice;
    constructor();
    isValid(): boolean;
    private generate16ByteNumber;
    generateWaitingID(): string;
    pid: string;
    ports: string[];
    clientIds: string[];
    projectNames: string[];
    uuid: string;
    ldcState: string;
    waitingIds: string[];
    serverType: string;
    serverTimeout: string;
    loginType: string;
    lastCommitDevice: LastCommitDevice;
}
//# sourceMappingURL=ldc_data.d.ts.map