import { ContainerModule } from "inversify";
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=udc-backend-module.d.ts.map