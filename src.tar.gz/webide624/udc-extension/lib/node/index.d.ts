export * from './udc-backend-module';
//# sourceMappingURL=index.d.ts.map