export declare class Packet {
    constructor();
    is_valid_type(type: string): boolean;
    construct(type: string, value: string): string;
    parse(msg: string): Array<any>;
    hash_of_file(filename: string): Promise<string>;
}
export declare namespace Packet {
    const LOG_JSON = "LGPD";
    const MULTI_DEVICE_PROGRAM = "MDPG";
    const QUERY_IDLE_DEVICES = "QIDV";
    const DEVICE_PROGRAM_QUEUE = "DPGQ";
    const DEVICE_PROGRAM_BEGIN = "DPBG";
    const TYPE_NONE = "NONE";
    const CLIENT_DEV = "CDEV";
    const ALL_DEV = "ADEV";
    const DEVICE_WAIT = "DPWT";
    const DEVICE_LOG = "DLOG";
    const DEVICE_STATUS = "DSTU";
    const DEVICE_CMD = "DCMD";
    const DEVICE_ERASE = "DERS";
    const DEVICE_PROGRAM = "DPRG";
    const DEVICE_RESET = "DRST";
    const DEVICE_START = "DSTR";
    const DEVICE_STOP = "DSTP";
    const DEVICE_ALLOC = "DALC";
    const DEVICE_DEBUG_START = "DDBS";
    const DEVICE_DEBUG_DATA = "DDBD";
    const DEVICE_DEBUG_REINIT = "DDBR";
    const DEVICE_DEBUG_STOP = "DDBE";
    const LOG_SUB = "LGSB";
    const LOG_UNSUB = "LGUS";
    const STATUS_SUB = "STSB";
    const STATUS_UNSUB = "STUS";
    const LOG_DOWNLOAD = "LGDL";
    const FILE_BEGIN = "FBGN";
    const FILE_DATA = "FDTA";
    const FILE_END = "FEND";
    const CMD_DONE = "CMDD";
    const CMD_ERROR = "CMDE";
    const HEARTBEAT = "HTBT";
    const CLIENT_LOGIN = "CLGI";
    const TERMINAL_LOGIN = "TLGI";
    const ACCESS_LOGIN = "ALGI";
    const ACCESS_REPORT_STATUS = "ARPS";
    const ACCESS_ADD_CLIENT = "AADC";
    const ACCESS_DEL_CLIENT = "ADLC";
    const ACCESS_ADD_TERMINAL = "AADT";
    const ACCESS_UPDATE_TERMINAL = "AUPT";
    const ACCESS_DEL_TERMINAL = "ADLT";
    const QUIZ_JUDGE = "QZJG";
    const GET_QUIZ_TOKEN = "GQZT";
    const GET_QUIZ_STATUS = "GQZS";
    const packet_type: {
        [key: string]: string;
    };
}
//# sourceMappingURL=packet.d.ts.map