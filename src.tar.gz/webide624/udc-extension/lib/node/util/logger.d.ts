export declare class Logger {
    static err(val: any, hintChar?: string): void;
    static info(val: any, hintChar?: string): void;
    static val(val: any, hintChar?: string): void;
}
//# sourceMappingURL=logger.d.ts.map