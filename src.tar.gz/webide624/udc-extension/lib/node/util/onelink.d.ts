import { UdcTerminal } from "./udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
import { CallInfoStorer } from "./callinfostorer";
export declare class OnelinkService {
    protected readonly ut: UdcTerminal;
    rootDir: RootDirPath;
    readonly cis: CallInfoStorer;
    ready: boolean;
    mobileFile: string;
    tokenPath: string;
    projectInfo: {
        projectName: string;
        token: string;
    };
    constructor(ut: UdcTerminal, rootDir: RootDirPath, cis: CallInfoStorer);
    prepare(pid: string): void;
    isReady(): boolean;
    getProjectInfo(tokenPath: string, projectName: string): {
        token: string;
        projectName: string;
    } | null;
    createProject(projectName: string, pid: string): Promise<boolean>;
    compileDevice(): Promise<boolean>;
    createMobileApp(mobileFile: string, projectName: string): Promise<boolean>;
    processBackValue(backValue: any): boolean;
    complileMobile(): Promise<boolean>;
    update(token: string, projectName: string, mobileFile: string, tokenPath: string): Promise<boolean>;
    openMobile(): Promise<void>;
    openDevice(): Promise<void>;
}
//# sourceMappingURL=onelink.d.ts.map