import { UdcTerminal } from "./udc-terminal";
import { Programer } from "./programmer";
import { RootDirPath } from "../../setting/backend-config";
export declare class LinkEdgeManager {
    protected readonly ut: UdcTerminal;
    protected readonly pm: Programer;
    rootDir: RootDirPath;
    constructor(ut: UdcTerminal, pm: Programer, rootDir: RootDirPath);
    delayNs(limit: number, f: (...[]: any[]) => boolean): Promise<boolean>;
    getIotId(): string;
    openConfigFile(pid: string): Promise<void>;
    initConfigDir(pid: string): Promise<boolean>;
    programGateWay(pid: string, threeTuple: any): Promise<Boolean | "err" | "fail">;
    processLinkEdgeConnect(pid: string, threeTuple: any): Promise<void>;
    addProjectToLinkEdge(pid: string, deviceInfo: any): Promise<boolean>;
    removeProjectInLinkEdge(pid: string, indexStr: string): Promise<boolean>;
    developLinkEdgeProject(pid: string, indexStr: string): Promise<true | undefined>;
}
//# sourceMappingURL=linkedgemanger.d.ts.map