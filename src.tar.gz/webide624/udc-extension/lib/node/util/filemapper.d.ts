export declare class FileMapper {
    private fileNameStorage;
    private fileDeviceStorage;
    getFileNameMapper(pid: string, rawName?: string): string | {
        [rawName: string]: string;
    };
    setFileNameMapper(pid: string, pair: {
        [rawName: string]: string;
    }): void;
    getFileDeviceMapper(pid: string, fileName?: string): string | {
        [fileName: string]: string;
    };
    setFileDeviceMapper(pid: string, pair: {
        [fileName: string]: string;
    }): void;
}
//# sourceMappingURL=filemapper.d.ts.map