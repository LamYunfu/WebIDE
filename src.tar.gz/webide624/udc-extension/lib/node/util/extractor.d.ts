import { UdcTerminal } from "./udc-terminal";
import { FileMapper } from "./filemapper";
import { RootDirPath } from "../../setting/backend-config";
export declare class Extractor {
    protected readonly fm: FileMapper;
    protected readonly ut: UdcTerminal;
    rootDir: RootDirPath;
    constructor(fm: FileMapper, ut: UdcTerminal, rootDir: RootDirPath);
    projectDir: string;
    hexFileDir: string;
    init(projectName: string, dirName: string): void;
    readonly hexFileDirectory: string;
    getHexName(fn: string): string;
    extract(pid: string): Promise<"err" | "scc">;
    extractSingleFile(pid: string, fn: string): Promise<"scc" | "failed">;
    outputResult(arg0: string): void;
}
//# sourceMappingURL=extractor.d.ts.map