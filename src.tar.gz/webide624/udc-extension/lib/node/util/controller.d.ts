/// <reference types="node" />
import { ConfigSetter } from "./configsetter";
import { Extractor } from "./extractor";
import { UdcTerminal } from "./udc-terminal";
import * as events from "events";
import { Compiler } from "../compilers/compiler";
import { Programer } from "./programmer";
import { RootDirPath } from "../../setting/backend-config";
import { BoardAndCompileType } from "../compilers/boardtocompilemethod";
export declare class Controller {
    protected readonly bat: BoardAndCompileType;
    protected readonly ut: UdcTerminal;
    protected readonly cm: Compiler;
    protected readonly et: Extractor;
    protected readonly pm: Programer;
    protected readonly cs: ConfigSetter;
    rootDir: RootDirPath;
    constructor(bat: BoardAndCompileType, ut: UdcTerminal, cm: Compiler, et: Extractor, pm: Programer, cs: ConfigSetter, // @inject(Event) protected readonly evt: Event
    rootDir: RootDirPath);
    events: events.EventEmitter;
    processDisplaySubmit(pid: string, info: string): Promise<void>;
    processFreeCoding(pid: string): Promise<void>;
    processIssue(pid: string): Promise<Boolean | "err" | "fail" | undefined>;
    processSingleFile(pid: string): Promise<false | "fail" | undefined>;
}
//# sourceMappingURL=controller.d.ts.map