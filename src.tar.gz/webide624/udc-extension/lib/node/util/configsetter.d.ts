/// <reference types="node" />
import { UdcTerminal } from './udc-terminal';
import * as EventEmitor from 'events';
export declare class ConfigSetter {
    protected readonly ut: UdcTerminal;
    constructor(ut: UdcTerminal);
    em: EventEmitor;
    on(): Promise<unknown>;
    fireOk(): void;
}
//# sourceMappingURL=configsetter.d.ts.map