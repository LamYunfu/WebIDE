export declare class CallInfoStorer {
    user: string;
    storeCallInfoInstantly(info: string, api: string, severity?: number): void;
    setUser(user: string): void;
    storeCallInfoLatter(time: string, info: string, api: string, severity?: number): void;
}
//# sourceMappingURL=callinfostorer.d.ts.map