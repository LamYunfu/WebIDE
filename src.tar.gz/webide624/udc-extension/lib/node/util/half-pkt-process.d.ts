/// <reference types="node" />
import * as EventEmitor from "events";
export declare class HalfPackProcess extends EventEmitor.EventEmitter {
    constructor();
    maxSize: number;
    dataBuffer: Buffer;
    cursorStart: number;
    cursorEnd: number;
    currentDataSize: number;
    callNum: number;
    putData(inData: Buffer): void;
    acquireData(): void;
}
//# sourceMappingURL=half-pkt-process.d.ts.map