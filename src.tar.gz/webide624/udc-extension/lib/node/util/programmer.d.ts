import { Extractor } from "./extractor";
import { FileMapper } from "./filemapper";
import { UdcTerminal } from "./udc-terminal";
import { RootDirPath } from "../../setting/backend-config";
import { CallInfoStorer } from "./callinfostorer";
export declare class Programer {
    protected readonly ut: UdcTerminal;
    protected readonly fm: FileMapper;
    protected readonly et: Extractor;
    rootDir: RootDirPath;
    readonly cis: CallInfoStorer;
    constructor(ut: UdcTerminal, fm: FileMapper, et: Extractor, rootDir: RootDirPath, cis: CallInfoStorer);
    fileUpload(filepath: string): Promise<string>;
    getHexName(fn: string): string;
    freeCodingProgram(pid: string): Promise<Boolean | "err" | undefined>;
    program(pid: string): Promise<Boolean | "fail">;
    programSingleFile(pid: string, fn: string): Promise<false | "fail" | undefined>;
}
//# sourceMappingURL=programmer.d.ts.map