import { Emitter, Event } from "@theia/core/lib/common/event";
export declare const UdcClient: unique symbol;
export interface UdcClient {
    OnDeviceLog(data: string): void;
    onDeviceList(data: {
        [key: string]: number;
    }): void;
    onConfigLog(data: {
        name: string;
        passwd: string;
    }): void;
}
export declare class UdcWatcher {
    protected onDeviceLogEmitter: Emitter<string>;
    protected onDeviceListEmitter: Emitter<{
        [key: string]: number;
    }>;
    protected onConfigEmitter: Emitter<{
        name: string;
        passwd: string;
    }>;
    getUdcWatcherClient(): UdcClient;
    readonly onConfigLog: Event<{
        name: string;
        passwd: string;
    }>;
    readonly onDeviceLog: Event<string>;
    readonly onDeviceList: Event<{
        [key: string]: number;
    }>;
}
//# sourceMappingURL=udc-watcher.d.ts.map