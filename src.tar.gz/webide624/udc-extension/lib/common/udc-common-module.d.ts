import { interfaces } from "inversify";
export declare function createCommonBindings(bind: interfaces.Bind): void;
//# sourceMappingURL=udc-common-module.d.ts.map