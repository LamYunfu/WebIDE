import { DrawboardService } from "../common/drawboardservice";
import { Client } from "../common/drawboardproxy";
export declare class DrawboardServiceImpl implements DrawboardService {
    client: Client | null;
    connection: any;
    device: any;
    aliIotDevAuthen: {
        "ProductKey": string;
        "DeviceName": string;
        "DeviceSecret": string;
    };
    aliIotAuthen: {
        uid: string;
        regionId: string;
        YourClientId: string;
        YourAccessKeyID: string;
        YourConsumerGroupId: string;
        YourAccessKeySecret: string;
    } | null;
    constructor();
    connectIot(authen: {
        uid: string;
        regionId: string;
        YourClientId: string;
        YourAccessKeyID: string;
        YourConsumerGroupId: string;
        YourAccessKeySecret: string;
        "ProductKey": string;
        "DeviceName": string;
        "DeviceSecret": string;
    }): Promise<boolean>;
    disconnectIot(): Promise<boolean>;
    hmacSha1(key: any, context: any): string;
    getDataFromIotPlatform(): Promise<string>;
    pushDataToIotPlatform(data: any): Promise<boolean>;
    setClient(client: Client): void;
}
//# sourceMappingURL=drawboardserviceimpl.d.ts.map