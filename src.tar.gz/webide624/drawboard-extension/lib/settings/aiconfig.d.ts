export declare const ModelTestAddress = "ws://47.98.249.190:8005/";
export declare const VOICE_RECOGNIZE_URL = "https://47.96.140.151:3004/voiceRecognize/";
//# sourceMappingURL=aiconfig.d.ts.map