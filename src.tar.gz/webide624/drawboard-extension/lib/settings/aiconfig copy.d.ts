export declare const ModelTestAddress = "ws://47.98.249.190:8005/";
//# sourceMappingURL=aiconfig copy.d.ts.map