import React = require("react");
export declare namespace Input {
    interface Props {
        onChange?: (e: any) => void;
        disabled?: boolean;
        label: string;
        hint: string;
        copy?: boolean;
    }
}
export declare class Input extends React.Component<Input.Props> {
    index: number;
    str: string;
    onChange: (e: any) => void;
    render(): JSX.Element;
    copy: () => void;
}
export declare namespace InstructionActionCollection {
    interface Props {
        instructionActionMappings: any;
    }
}
export declare class InstructionActionCollection extends React.Component<InstructionActionCollection.Props> {
    render(): JSX.Element;
}
export declare namespace InstructionActionMapping {
    interface props {
        instruction: string;
        action: string;
    }
}
export declare class InstructionActionMapping extends React.Component<InstructionActionMapping.props> {
    render(): JSX.Element;
}
//# sourceMappingURL=input.d.ts.map