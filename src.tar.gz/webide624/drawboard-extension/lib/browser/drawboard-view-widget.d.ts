import { TreeWidget, TreeNode, NodeProps, SelectableTreeNode, TreeProps, ContextMenuRenderer, TreeModel, ExpandableTreeNode } from '@theia/core/lib/browser';
import { Message } from '@phosphor/messaging';
import { Emitter } from '@theia/core';
import { CompositeTreeNode } from '@theia/core/lib/browser';
import * as React from 'react';
import { DrawboardService } from '../common/drawboardservice';
export interface DrawboardSymbolInformationNode extends CompositeTreeNode, SelectableTreeNode, ExpandableTreeNode {
    iconClass: string;
}
export declare namespace DrawboardSymbolInformationNode {
    function is(node: TreeNode): node is DrawboardSymbolInformationNode;
}
export declare type DrawboardViewWidgetFactory = () => DrawboardViewWidget;
export declare const DrawboardViewWidgetFactory: unique symbol;
export declare class DrawboardViewWidget extends TreeWidget {
    protected readonly treeProps: TreeProps;
    protected readonly contextMenuRenderer: ContextMenuRenderer;
    protected readonly ds: DrawboardService;
    readonly onDidChangeOpenStateEmitter: Emitter<boolean>;
    iamap: any;
    constructor(treeProps: TreeProps, model: TreeModel, contextMenuRenderer: ContextMenuRenderer, ds: DrawboardService);
    setDrawboardTree(roots: DrawboardSymbolInformationNode[]): void;
    protected reconcileTreeState(nodes: TreeNode[]): TreeNode[];
    protected onAfterHide(msg: Message): void;
    protected onAfterShow(msg: Message): void;
    renderIcon(node: TreeNode, props: NodeProps): React.ReactNode;
    protected createNodeAttributes(node: TreeNode, props: NodeProps): React.Attributes & React.HTMLAttributes<HTMLElement>;
    protected getNodeTooltip(node: TreeNode): string | undefined;
    protected isExpandable(node: TreeNode): node is ExpandableTreeNode;
    protected renderTree(): React.ReactNode;
    getData: () => Promise<string>;
    pushDate: (data: any) => Promise<boolean>;
    setIaMap(iamap: any): void;
    connect: (authen: any) => Promise<boolean>;
    disconnect: () => Promise<boolean>;
}
//# sourceMappingURL=drawboard-view-widget.d.ts.map