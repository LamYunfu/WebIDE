import React = require("react");
export declare namespace View {
    interface Props {
        iamap: any;
        getData: () => Promise<string>;
        pushData: (data: any) => Promise<boolean>;
        connect: (authen: any) => Promise<boolean>;
        disconnect: () => Promise<boolean>;
    }
}
export declare class View extends React.Component<View.Props> {
    boardType: string | undefined;
    title: string | undefined;
    ws: WebSocket | undefined;
    aliIotAuthen: {
        uid: string;
        regionId: string;
        YourClientId: string;
        YourAccessKeyID: string;
        YourConsumerGroupId: string;
        YourAccessKeySecret: string;
        "ProductKey": string;
        "DeviceName": string;
        "DeviceSecret": string;
    };
    componentWillMount(): void;
    recv: (e: any) => void;
    connect(): void;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
    connectIot: () => Promise<boolean>;
    disconnectIot: () => Promise<boolean>;
}
export declare namespace ConnectButton {
    interface Props {
        connect: () => Promise<boolean>;
        disconnect: () => Promise<boolean>;
    }
    interface Status {
        disable: boolean;
        connected: boolean;
    }
}
export declare class ConnectButton extends React.Component<ConnectButton.Props, ConnectButton.Status> {
    constructor(props: any);
    render(): JSX.Element;
    disconnect: () => Promise<void>;
    connect: () => Promise<void>;
}
//# sourceMappingURL=renderview.d.ts.map