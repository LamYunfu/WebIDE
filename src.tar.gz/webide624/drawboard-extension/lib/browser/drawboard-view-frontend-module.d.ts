import { ContainerModule } from 'inversify';
import '../../src/browser/styles/index.css';
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=drawboard-view-frontend-module.d.ts.map