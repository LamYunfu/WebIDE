import { Event, Emitter } from '@theia/core';
import { WidgetFactory } from '@theia/core/lib/browser';
import { DrawboardViewWidget, DrawboardViewWidgetFactory, DrawboardSymbolInformationNode } from './drawboard-view-widget';
import { Widget } from '@phosphor/widgets';
import { ProxyObject } from '../common/drawboardproxy';
export declare class DrawboardViewService implements WidgetFactory {
    protected factory: DrawboardViewWidgetFactory;
    protected readonly po: ProxyObject;
    id: string;
    protected widget?: DrawboardViewWidget;
    protected readonly onDidChangeDrawboardEmitter: Emitter<DrawboardSymbolInformationNode[]>;
    protected readonly onDidChangeOpenStateEmitter: Emitter<boolean>;
    protected readonly onDidSelectEmitter: Emitter<DrawboardSymbolInformationNode>;
    protected readonly onDidOpenEmitter: Emitter<DrawboardSymbolInformationNode>;
    constructor(factory: DrawboardViewWidgetFactory, po: ProxyObject);
    readonly onDidSelect: Event<DrawboardSymbolInformationNode>;
    readonly onDidOpen: Event<DrawboardSymbolInformationNode>;
    readonly onDidChangeDrawboard: Event<DrawboardSymbolInformationNode[]>;
    readonly onDidChangeOpenState: Event<boolean>;
    readonly open: boolean;
    publish(roots: DrawboardSymbolInformationNode[]): void;
    createWidget(): Promise<Widget>;
}
//# sourceMappingURL=drawboard-view-service.d.ts.map