import { AbstractViewContribution } from '@theia/core/lib/browser/shell/view-contribution';
import { DrawboardViewWidget } from './drawboard-view-widget';
import { FrontendApplicationContribution, FrontendApplication } from '@theia/core/lib/browser/frontend-application';
export declare const OUTLINE_WIDGET_FACTORY_ID = "drawboard-view";
export declare class DrawboardViewContribution extends AbstractViewContribution<DrawboardViewWidget> implements FrontendApplicationContribution {
    constructor();
    initializeLayout(app: FrontendApplication): Promise<void>;
}
//# sourceMappingURL=drawboard-view-contribution.d.ts.map