import { Emitter, Event } from "@theia/core";
import { interfaces } from "inversify";
export declare const Client: unique symbol;
export declare const SERVICE_PATH = "/services/drawboardproxy";
export interface Client {
    fire(data: {
        type: string;
        data: any;
    }): void;
}
export declare class ProxyObject {
    protected em: Emitter<{
        type: string;
        data: any;
    }>;
    readonly register: Event<{
        type: string;
        data: any;
    }>;
    getClient(): {
        fire(data: {
            type: string;
            data: any;
        }): void;
    };
}
export declare function createCommonBind(bind: interfaces.Bind): void;
//# sourceMappingURL=drawboardproxy.d.ts.map