import { DemoService } from '../common/demo-service';
import { Client } from '../common/test';
export declare class ServiceImpl implements DemoService {
    protected client: Client | null;
    say(): void;
    setClient(client: Client): void;
}
//# sourceMappingURL=demo-service-impl.d.ts.map