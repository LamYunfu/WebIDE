import { WidgetFactory, Widget, ApplicationShell } from "@theia/core/lib/browser";
import { Emitter } from "@theia/core/lib/common/event";
import { DemoViewSymbolInformationNode, DemoWidgetFactory, DemoWidget } from "./demo-widget";
export declare class DemoViewService implements WidgetFactory {
    protected factory: DemoWidgetFactory;
    protected shell: ApplicationShell;
    id: string;
    protected readonly onDidChangeDemoEmitter: Emitter<DemoViewSymbolInformationNode[]>;
    protected readonly onDidChangeOpenStateEmitter: Emitter<boolean>;
    protected readonly onDidOpenEmitter: Emitter<DemoViewSymbolInformationNode>;
    protected readonly onDidSelectEmitter: Emitter<DemoViewSymbolInformationNode>;
    protected widget?: DemoWidget;
    constructor(factory: DemoWidgetFactory, shell: ApplicationShell);
    createWidget(): Promise<Widget>;
    say(s: string): void;
}
//# sourceMappingURL=demo-widget-sservice.d.ts.map