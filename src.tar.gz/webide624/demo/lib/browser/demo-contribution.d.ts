import { AbstractViewContribution, FrontendApplication } from "@theia/core/lib/browser";
import { DemoWidget } from "./demo-widget";
import { DemoViewService } from "./demo-widget-sservice";
import { MenuContribution } from "@theia/core";
export declare class DemoContribution extends AbstractViewContribution<DemoWidget> implements MenuContribution {
    protected readonly dvs: DemoViewService;
    constructor(dvs: DemoViewService);
    onStart?(app: FrontendApplication): void;
}
//# sourceMappingURL=demo-contribution.d.ts.map