import { ContainerModule } from "inversify";
import { TreeProps } from "@theia/core/lib/browser";
export declare const FILE_NAVIGATOR_PROPS: TreeProps;
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=demo-frontend-module.d.ts.map