import { TreeProps, ContextMenuRenderer, CompositeTreeNode, SelectableTreeNode, TreeNode } from "@theia/core/lib/browser";
import React = require("react");
import { Emitter } from "vscode-jsonrpc";
import { WorkspaceService } from "@theia/workspace/lib/browser";
import { ApplicationShell } from "@theia/core/lib/browser/shell/application-shell";
import { FileNavigatorModel, FileNavigatorWidget } from "@theia/navigator/lib/browser/";
import { FileSystem } from "@theia/filesystem/lib/common/filesystem";
import { CommandService, SelectionService } from "@theia/core";
import { UdcService } from "udc-extension/lib/common/udc-service";
export interface DemoViewSymbolInformationNode extends CompositeTreeNode, SelectableTreeNode {
    iconClass: string;
}
export declare namespace DemoViewSymbolInformationNode {
    function is(node: TreeNode): node is DemoViewSymbolInformationNode;
}
export declare type DemoWidgetFactory = () => DemoWidget;
export declare const DemoWidgetFactory: unique symbol;
export declare class DemoWidget extends FileNavigatorWidget {
    protected readonly treePros: TreeProps;
    protected readonly udcService: UdcService;
    readonly model: FileNavigatorModel;
    protected readonly commandService: CommandService;
    protected readonly selectionService: SelectionService;
    protected readonly workspaceService: WorkspaceService;
    protected readonly shell: ApplicationShell;
    protected readonly fileSystem: FileSystem;
    readonly onDidChangeOpenStateEmitter: Emitter<boolean>;
    device_list?: {
        [key: string]: number;
    };
    ppid: string | undefined;
    constructor(treePros: TreeProps, udcService: UdcService, model: FileNavigatorModel, contextMenuRenderer: ContextMenuRenderer, commandService: CommandService, selectionService: SelectionService, workspaceService: WorkspaceService, shell: ApplicationShell, fileSystem: FileSystem);
    getPpid(): string | undefined;
    submitEnableWithJudgeTag: boolean;
    rootdir: string;
    viewType: string;
    protected renderTree(): React.ReactNode;
    getIotID(): Promise<string>;
    createUrl(id: string, key: string): string;
    creatEdgeInstance: () => Promise<void>;
    createDeviceDriver: () => Promise<void>;
    createRuleCaculation: () => Promise<void>;
    createAppManagement: () => Promise<void>;
    createFlowCaculation: () => Promise<void>;
    createMessageRouting: () => Promise<void>;
}
//# sourceMappingURL=demo-widget.d.ts.map