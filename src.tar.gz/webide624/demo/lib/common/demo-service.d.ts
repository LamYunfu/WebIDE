import { Client } from "./test";
export declare const DemoService: unique symbol;
export interface DemoService {
    say(): void;
    setClient(client: Client): void;
}
//# sourceMappingURL=demo-service.d.ts.map