import { Emitter, Event } from "@theia/core";
export declare const Client: unique symbol;
export interface Client {
    fire(somthing: string): void;
}
export declare class ClientObject {
    protected onDeviceLogEmitter: Emitter<string>;
    readonly register: Event<string>;
    fire(): {
        fire(somthing: string): void;
    };
}
//# sourceMappingURL=test.d.ts.map