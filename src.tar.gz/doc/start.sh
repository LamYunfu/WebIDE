#!/bin/bash
while [ "1" != "2" ]
do
        ./clear_docker.sh
        sleep 1h

done