// import { UdcServiceImpl } from './udc-service-impl';
// import { Container,ContainerModule } from "inversify";
// import { bindLogger } from '@theia/core/lib/node/logger-backend-module';
// import processBackendModule from '@theia/process/lib/node/process-backend-module';


// const testContainer = new Container();

// bindLogger(testContainer.bind.bind(testContainer));
// testContainer.load(processBackendModule);
// testContainer.load(new ContainerModule(bind => {
//     bind(UdcServiceImpl).toSelf().inSingletonScope();
// }));


// describe('udc-service',function(){
    
//     this.timeout(10000);

//     let service: UdcServiceImpl;

//     beforeEach(() => {
//         service = testContainer.get(UdcServiceImpl);
//     });

//     it('udc service')
// })

